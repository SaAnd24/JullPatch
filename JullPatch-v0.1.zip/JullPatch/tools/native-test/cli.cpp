// Host-side test driver for the native engine (not part of the Android build).
// usage: jullpatch_cli <source> <patch> <output> [cancel_after_bytes]
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cstdio>
#include <cstdlib>

#include "../../app/src/main/cpp/vcdiff/fd_io.h"
#include "../../app/src/main/cpp/vcdiff/vcdiff_decoder.h"

int main(int argc, char** argv) {
    using namespace jullpatch;
    if (argc < 4) {
        std::fprintf(stderr, "usage: %s source patch output [cancel_after_output_bytes]\n", argv[0]);
        return 64;
    }
    const uint64_t cancelAfter = argc > 4 ? std::strtoull(argv[4], nullptr, 10) : 0;
    int s = open(argv[1], O_RDONLY), p = open(argv[2], O_RDONLY);
    int o = open(argv[3], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (s < 0 || p < 0 || o < 0) {
        std::perror("open");
        return 65;
    }
    struct stat ss, ps;
    fstat(s, &ss);
    fstat(p, &ps);
    FdIO io(s, p, o, ss.st_size, ps.st_size,
            [&](uint64_t, uint64_t out) { return !(cancelAfter && out >= cancelAfter); },
            /*minProgressIntervalNs=*/0);
    Result r = VcdiffDecoder(io).run();
    io.sync();
    std::printf("status=%d output=%llu msg=%s\n", (int)r.status, (unsigned long long)r.outputBytes,
                r.message.c_str());
    return (int)r.status;
}
