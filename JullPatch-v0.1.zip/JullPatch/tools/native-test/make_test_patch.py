#!/usr/bin/env python3
"""Generates real VCDIFF (".xdelta"-compatible) patches for testing the native engine.

This is an independent encoder written from RFC 3284: it exercises ADD/RUN/COPY, all
address modes (SELF/HERE/NEAR/SAME), combined opcodes of the default code table,
multiple windows, Adler-32 window checksums (xdelta3 extension), app header and
LZMA secondary compression (liblzma "alone" and ".xz"/LZMA2 containers).
"""
import argparse, lzma, os, random, struct, zlib


def varint(n):
    out = [n & 0x7F]
    n >>= 7
    while n:
        out.append(0x80 | (n & 0x7F))
        n >>= 7
    return bytes(reversed(out))


class Cache:
    def __init__(self):
        self.near = [0] * 4
        self.same = [0] * 768
        self.nxt = 0

    def encode(self, addr, here):
        cands = [(len(varint(addr)), 0, varint(addr))]
        cands.append((len(varint(here - addr)), 1, varint(here - addr)))
        for i in range(4):
            if addr >= self.near[i]:
                d = addr - self.near[i]
                cands.append((len(varint(d)), 2 + i, varint(d)))
        if self.same[addr % 768] == addr:
            cands.append((1, 6 + (addr % 768) // 256, bytes([addr % 256])))
        cands.sort(key=lambda c: (c[0], -c[1]))
        _, mode, data = cands[0]
        self.near[self.nxt] = addr
        self.nxt = (self.nxt + 1) % 4
        self.same[addr % 768] = addr
        return mode, data


def secondary(data, kind):
    if not data or kind == "none":
        return data, False
    if kind == "alone":
        comp = lzma.compress(data, format=lzma.FORMAT_ALONE,
                             filters=[{"id": lzma.FILTER_LZMA1, "preset": 6}])
    else:  # xz
        comp = lzma.compress(data, format=lzma.FORMAT_XZ, check=lzma.CHECK_NONE)
    return varint(len(data)) + comp, True


def build_window(ops, src_pos, src_len, kind, adler, target, rnd):
    cache = Cache()
    add_data, inst, addrs = bytearray(), bytearray(), bytearray()
    insts = []  # (type, size, mode)
    pos = 0
    tgt = bytearray()
    for op in ops:
        if op[0] == "add":
            add_data += op[1]; insts.append(("add", len(op[1]), 0)); tgt += op[1]
        elif op[0] == "run":
            add_data.append(op[1]); insts.append(("run", op[2], 0)); tgt += bytes([op[1]]) * op[2]
        else:
            if op[0] == "src":
                addr, size = op[1] - src_pos, op[2]
                data = target_source_slice(op)
            else:  # copy from the target window itself (may overlap)
                addr, size = src_len + (len(tgt) - op[1]), op[2]
                start = len(tgt) - op[1]
                if size <= op[1]:
                    data = tgt[start:start + size]
                else:  # overlapping copy repeats the last `dist` bytes
                    unit = bytes(tgt[start:])
                    data = (unit * (size // len(unit) + 1))[:size]
            here = src_len + len(tgt)
            mode, enc = cache.encode(addr, here)
            addrs += enc
            insts.append(("copy", size, mode))
            tgt += data
    i = 0
    while i < len(insts):
        t, s, m = insts[i]
        nxt = insts[i + 1] if i + 1 < len(insts) else None
        if t == "add" and 1 <= s <= 4 and nxt and nxt[0] == "copy":
            if 4 <= nxt[1] <= 6 and nxt[2] < 6:
                inst.append(163 + nxt[2] * 12 + (s - 1) * 3 + (nxt[1] - 4)); i += 2; continue
            if nxt[1] == 4 and nxt[2] >= 6:
                inst.append(235 + (nxt[2] - 6) * 4 + (s - 1)); i += 2; continue
        if t == "copy" and s == 4 and nxt and nxt[0] == "add" and nxt[1] == 1:
            inst.append(247 + m); i += 2; continue
        if t == "add":
            if s <= 17: inst.append(1 + s)
            else: inst.append(1); inst += varint(s)
        elif t == "run":
            inst.append(0); inst += varint(s)
        else:
            base = 19 + 16 * m
            if 4 <= s <= 18: inst.append(base + s - 3)
            else: inst.append(base); inst += varint(s)
        i += 1

    delta_ind = 0
    secs = []
    for bit, sec in ((1, bytes(add_data)), (2, bytes(inst)), (4, bytes(addrs))):
        enc, used = secondary(sec, kind)
        if used: delta_ind |= bit
        secs.append(enc)
    body = varint(len(tgt)) + bytes([delta_ind]) + varint(len(secs[0])) + varint(len(secs[1])) + varint(len(secs[2]))
    win_ind = 1 if src_len else 0
    if adler:
        win_ind |= 4
        body += struct.pack(">I", zlib.adler32(bytes(tgt)))
    body += secs[0] + secs[1] + secs[2]
    out = bytes([win_ind])
    if src_len: out += varint(src_len) + varint(src_pos)
    out += varint(len(body)) + body
    return out, bytes(tgt)


SOURCE = None
def target_source_slice(op):
    return SOURCE(op[1], op[2])


def main():
    global SOURCE
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("--source-size", type=int, default=3_000_000)
    ap.add_argument("--target-size", type=int, default=4_000_000)
    ap.add_argument("--window", type=int, default=1_000_000)
    ap.add_argument("--secondary", choices=["none", "alone", "xz"], default="none")
    ap.add_argument("--no-adler", action="store_true")
    ap.add_argument("--no-appheader", action="store_true")
    ap.add_argument("--sparse-source", action="store_true", help="zero-filled sparse source (use with huge sizes)")
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    rnd = random.Random(a.seed)
    os.makedirs(a.outdir, exist_ok=True)
    src_path = os.path.join(a.outdir, "source.bin")
    if a.sparse_source:
        with open(src_path, "wb") as f:
            f.truncate(a.source_size)
            # a few marker blocks so copies are verifiable
            for off in range(0, a.source_size, max(a.source_size // 50, 1)):
                f.seek(off); f.write(rnd.randbytes(4096))
    else:
        chunk = rnd.randbytes(1 << 20)
        with open(src_path, "wb") as f:
            left = a.source_size
            while left > 0:
                n = min(left, len(chunk))
                # semi-random: rotate chunk so the file is not periodic
                f.write(chunk[(left % 997):(left % 997) + n] if left % 997 + n <= len(chunk) else rnd.randbytes(n))
                left -= n
    sf = open(src_path, "rb")
    def src_slice(off, n):
        sf.seek(off); return sf.read(n)
    SOURCE = src_slice

    words = [b"hello", b"world", b"JullPatch", b"xdelta", b"\x00\x00\x00\x00", b" the ", b"patch"]
    patch = bytearray(b"\xD6\xC3\xC4\x00")
    hdr = 0
    if a.secondary != "none": hdr |= 1
    if not a.no_appheader: hdr |= 4
    patch.append(hdr)
    if hdr & 1: patch.append(2)
    if hdr & 4:
        app = b"xdelta3 -e -s source.bin target.bin patch.xdelta"
        patch += varint(len(app)) + app

    target = bytearray()
    prev_end = 0
    while len(target) < a.target_size:
        ops, wlen = [], 0
        win_start = len(target)
        while wlen < a.window and win_start + wlen < a.target_size:
            r = rnd.random()
            if r < 0.5 and a.source_size > 100:
                n = rnd.choice([4, 5, 6, 12, 40, 300, 5000, rnd.randint(1, 60000)])
                n = min(n, a.source_size)
                if rnd.random() < 0.5:
                    off = min(prev_end + rnd.randint(0, 50), a.source_size - n)
                else:
                    off = rnd.randint(0, a.source_size - n)
                prev_end = off + n
                ops.append(("src", off, n)); wlen += n
            elif r < 0.75:
                n = rnd.choice([1, 2, 3, 4, 17, 18, 200, 5000])
                data = rnd.randbytes(n) if rnd.random() < 0.5 else (rnd.choice(words) * (n // 3 + 1))[:n]
                ops.append(("add", data)); wlen += n
            elif r < 0.85:
                n = rnd.randint(1, 3000); ops.append(("run", rnd.randrange(256), n)); wlen += n
            elif wlen > 0:
                n = rnd.choice([4, 5, 6, 40, 700])
                dist = rnd.randint(1, wlen)
                ops.append(("tgt", dist, n)); wlen += n
        srcs = [o for o in ops if o[0] == "src"]
        if srcs:
            lo = min(o[1] for o in srcs); hi = max(o[1] + o[2] for o in srcs)
            src_pos, src_len = lo, hi - lo
        else:
            src_pos = src_len = 0
        # The 'tgt' ops are relative to window start, so build_window handles them via len(tgt)
        win, tgt = build_window(ops, src_pos, src_len, a.secondary, not a.no_adler, None, rnd)
        patch += win
        target += tgt
    with open(os.path.join(a.outdir, "patch.xdelta"), "wb") as f: f.write(patch)
    with open(os.path.join(a.outdir, "expected.bin"), "wb") as f: f.write(target)
    print(f"source={a.source_size} target={len(target)} patch={len(patch)} secondary={a.secondary}")


if __name__ == "__main__":
    main()
