# JullPatch v0.1 — XDelta Core

Android app (Kotlin + Jetpack Compose + NDK/C++) that applies `.xdelta` (VCDIFF, RFC 3284) patches locally.

## Build
Open the folder in Android Studio (Ladybug or newer). It will download Gradle 8.9, and will ask to install
the NDK and CMake 3.22.1 from the SDK Manager. JDK 17. `gradle-wrapper.jar` is not included
(binary): Android Studio does not need it; from a terminal run `gradle wrapper` once.

## Layout
- `app/src/main/cpp/vcdiff/` portable engine (VCDIFF decoder, LZMA/LZMA2, fd IO) — no Android deps
- `app/src/main/cpp/jni/` JNI bridge
- `.../domain/` models, `PatchEngine`, `FileGateway`, `ApplyPatchUseCase` (no UI, no JNI)
- `.../data/engine/` `XdeltaPatchEngine` + `NativeXdelta` (JNI)
- `.../data/files/` Storage Access Framework gateway
- `.../service/` `PatchJobManager` (job + cancel) and `PatchForegroundService`
- `.../ui/` ViewModel + Compose screens
- `tools/native-test/` host tests for the engine: `bash tools/native-test/run_tests.sh` (needs g++ and python3)

New patch formats: implement `PatchEngine` and register it in `AppContainer`.
