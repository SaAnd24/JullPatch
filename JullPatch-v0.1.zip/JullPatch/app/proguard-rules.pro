# JNI: the native library looks up these members by name.
-keep class com.jullpatch.app.data.engine.NativeXdelta { *; }
-keep interface com.jullpatch.app.data.engine.NativeXdelta$Listener { *; }
-keepclassmembers class * implements com.jullpatch.app.data.engine.NativeXdelta$Listener { *; }
