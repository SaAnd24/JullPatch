package com.jullpatch.app.ui

import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class FormattersTest {
    @Before
    fun setUp() {
        Locale.setDefault(Locale.US)
    }

    @Test
    fun formatBytes_smallValues() {
        assertEquals("0 B", formatBytes(0))
        assertEquals("1023 B", formatBytes(1023))
    }

    @Test
    fun formatBytes_scalesUnits() {
        assertEquals("1.50 KB", formatBytes(1536))
        assertEquals("4.00 GB", formatBytes(4L * 1024 * 1024 * 1024))
    }

    @Test
    fun formatPercent_clamps() {
        assertEquals("0%", formatPercent(0f))
        assertEquals("42%", formatPercent(0.425f))
        assertEquals("100%", formatPercent(1.7f))
    }

    @Test
    fun suggestOutputName_keepsExtension() {
        assertEquals("game_patched.iso", suggestOutputName("game.iso"))
        assertEquals("noext_patched", suggestOutputName("noext"))
        assertEquals(".hidden_patched", suggestOutputName(".hidden"))
    }
}
