#pragma once
#include <cstdint>
#include <string>

namespace jullpatch {

// Keep numeric values in sync with NativeStatus in Kotlin (NativeXdelta.kt).
enum class Status : int {
    Ok = 0,
    Cancelled = 1,
    NotVcdiff = 2,
    CorruptPatch = 3,
    Unsupported = 4,
    SourceReadError = 5,
    PatchReadError = 6,
    OutputWriteError = 7,
    NoSpace = 8,
    ChecksumMismatch = 9,
    OutOfMemory = 10,
    Internal = 11,
    SourceNotSeekable = 12,
    SourceTooSmall = 13,
};

struct Result {
    Status status = Status::Ok;
    std::string message;
    uint64_t outputBytes = 0;
};

}  // namespace jullpatch
