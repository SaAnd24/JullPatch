#pragma once
#include <sys/types.h>

#include <cstddef>
#include <cstdint>

#include "status.h"

namespace jullpatch {

constexpr uint64_t kUnknownSize = UINT64_MAX;

// Abstract IO used by the VCDIFF decoder. The decoder never touches file
// descriptors directly, which keeps it testable and reusable.
class PatchIO {
public:
    virtual ~PatchIO() = default;

    // Sequential read of the patch. Returns bytes read, 0 on EOF, -1 on error.
    virtual ssize_t readPatch(uint8_t* dst, size_t n) = 0;

    // Random-access exact read of the source file.
    virtual Status readSource(uint64_t offset, uint8_t* dst, size_t n) = 0;

    // Sequential write of the output file (writes everything or fails).
    virtual Status writeOutput(const uint8_t* src, size_t n) = 0;

    // Progress notification. Return false to request cancellation.
    virtual bool onProgress(uint64_t patchBytesRead, uint64_t outputBytes) = 0;

    virtual uint64_t sourceSize() const = 0;  // kUnknownSize if unknown
    virtual uint64_t patchSize() const = 0;   // kUnknownSize if unknown
};

}  // namespace jullpatch
