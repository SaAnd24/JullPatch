#include "vcdiff_decoder.h"

#include <cstring>
#include <memory>
#include <new>
#include <vector>

#include "lzma_decoder.h"

namespace jullpatch {
namespace {

constexpr uint64_t kMaxWindowBytes = 256ull * 1024 * 1024;  // sanity cap per window / section
constexpr size_t kWriteChunk = 1u << 20;
constexpr unsigned kInstructionsPerCancelCheck = 8192;

constexpr uint8_t kWinSource = 0x01;
constexpr uint8_t kWinTarget = 0x02;
constexpr uint8_t kWinAdler32 = 0x04;

constexpr uint8_t kSecondaryLzma = 2;
constexpr uint8_t kSecondaryDjw = 1;
constexpr uint8_t kSecondaryFgk = 16;

enum InstType : uint8_t { kNoop = 0, kAdd = 1, kRun = 2, kCopy = 3 };

struct Inst {
    uint8_t type;
    uint8_t size;
    uint8_t mode;
};
struct CodeEntry {
    Inst first, second;
};

// RFC 3284 section 5.6 default code table.
struct CodeTable {
    CodeEntry e[256];
    CodeTable() {
        std::memset(e, 0, sizeof(e));
        int i = 0;
        e[i++] = {{kRun, 0, 0}, {kNoop, 0, 0}};
        for (uint8_t s = 0; s <= 17; s++) e[i++] = {{kAdd, s, 0}, {kNoop, 0, 0}};
        for (uint8_t mode = 0; mode < 9; mode++) {
            e[i++] = {{kCopy, 0, mode}, {kNoop, 0, 0}};
            for (uint8_t s = 4; s <= 18; s++) e[i++] = {{kCopy, s, mode}, {kNoop, 0, 0}};
        }
        for (uint8_t mode = 0; mode < 6; mode++)
            for (uint8_t a = 1; a <= 4; a++)
                for (uint8_t c = 4; c <= 6; c++) e[i++] = {{kAdd, a, 0}, {kCopy, c, mode}};
        for (uint8_t mode = 6; mode < 9; mode++)
            for (uint8_t a = 1; a <= 4; a++) e[i++] = {{kAdd, a, 0}, {kCopy, 4, mode}};
        for (uint8_t mode = 0; mode < 9; mode++) e[i++] = {{kCopy, 4, mode}, {kAdd, 1, 0}};
    }
};
const CodeTable& codeTable() {
    static const CodeTable table;
    return table;
}

uint32_t adler32(const uint8_t* data, size_t len) {
    uint32_t a = 1, b = 0;
    while (len > 0) {
        size_t n = len < 5552 ? len : 5552;
        len -= n;
        while (n--) {
            a += *data++;
            b += a;
        }
        a %= 65521;
        b %= 65521;
    }
    return (b << 16) | a;
}

// Reads from an in-memory section.
struct MemReader {
    const uint8_t* p;
    size_t size;
    size_t pos = 0;
    MemReader(const std::vector<uint8_t>& v) : p(v.data()), size(v.size()) {}
    bool byte(uint8_t& b) {
        if (pos >= size) return false;
        b = p[pos++];
        return true;
    }
    bool varint(uint64_t& v) {
        v = 0;
        for (int i = 0; i < 10; i++) {
            if (pos >= size) return false;
            uint8_t b = p[pos++];
            if (v > (UINT64_MAX >> 7)) return false;
            v = (v << 7) | (b & 0x7F);
            if (!(b & 0x80)) return true;
        }
        return false;
    }
};

// Buffered sequential reader over PatchIO::readPatch.
class PatchReader {
public:
    explicit PatchReader(PatchIO& io) : io_(io), buf_(1u << 16) {}

    Status status() const { return status_; }
    const std::string& message() const { return message_; }
    uint64_t consumed() const { return consumed_; }

    // True when the patch ended cleanly (no more bytes, no error).
    bool atCleanEnd() { return !fill() && status_ == Status::Ok; }

    size_t readSome(uint8_t* dst, size_t n) {
        size_t done = 0;
        while (done < n && fill()) {
            size_t k = std::min(n - done, len_ - pos_);
            std::memcpy(dst + done, buf_.data() + pos_, k);
            pos_ += k;
            done += k;
            consumed_ += k;
        }
        return done;
    }
    bool readBytes(uint8_t* dst, size_t n) {
        if (readSome(dst, n) == n) return true;
        truncated();
        return false;
    }
    bool skip(uint64_t n) {
        while (n > 0) {
            if (!fill()) {
                truncated();
                return false;
            }
            size_t k = static_cast<size_t>(std::min<uint64_t>(n, len_ - pos_));
            pos_ += k;
            consumed_ += k;
            n -= k;
        }
        return true;
    }
    bool readByte(uint8_t& b) { return readBytes(&b, 1); }
    bool readVarint(uint64_t& v) {
        v = 0;
        for (int i = 0; i < 10; i++) {
            uint8_t b;
            if (!readByte(b)) return false;
            if (v > (UINT64_MAX >> 7)) {
                corrupt("Número fuera de rango en el parche");
                return false;
            }
            v = (v << 7) | (b & 0x7F);
            if (!(b & 0x80)) return true;
        }
        corrupt("Número inválido en el parche");
        return false;
    }
    void corrupt(const char* msg) {
        if (status_ == Status::Ok) {
            status_ = Status::CorruptPatch;
            message_ = msg;
        }
    }

private:
    bool fill() {
        if (pos_ < len_) return true;
        if (eof_ || status_ != Status::Ok) return false;
        ssize_t n = io_.readPatch(buf_.data(), buf_.size());
        if (n < 0) {
            status_ = Status::PatchReadError;
            message_ = "Error de lectura del parche";
            eof_ = true;
            return false;
        }
        if (n == 0) {
            eof_ = true;
            return false;
        }
        pos_ = 0;
        len_ = static_cast<size_t>(n);
        return true;
    }
    void truncated() { corrupt("El parche termina de forma inesperada (truncado)"); }

    PatchIO& io_;
    std::vector<uint8_t> buf_;
    size_t pos_ = 0, len_ = 0;
    uint64_t consumed_ = 0;
    bool eof_ = false;
    Status status_ = Status::Ok;
    std::string message_;
};

// RFC 3284 section 5.3 address cache (s_near = 4, s_same = 3).
class AddressCache {
public:
    AddressCache() { reset(); }
    void reset() {
        std::memset(near_, 0, sizeof(near_));
        std::memset(same_, 0, sizeof(same_));
        next_ = 0;
    }
    bool decode(uint64_t here, unsigned mode, MemReader& addrs, uint64_t& out) {
        uint64_t v;
        if (mode == 0) {
            if (!addrs.varint(v)) return false;
            out = v;
        } else if (mode == 1) {
            if (!addrs.varint(v) || v > here) return false;
            out = here - v;
        } else if (mode < 2 + kNear) {
            if (!addrs.varint(v)) return false;
            out = near_[mode - 2] + v;
        } else {
            uint8_t b;
            if (!addrs.byte(b)) return false;
            out = same_[(mode - (2 + kNear)) * 256 + b];
        }
        near_[next_] = out;
        next_ = (next_ + 1) % kNear;
        same_[out % (kSame * 256)] = out;
        return true;
    }

private:
    static constexpr unsigned kNear = 4;
    static constexpr unsigned kSame = 3;
    uint64_t near_[kNear];
    uint64_t same_[kSame * 256];
    unsigned next_;
};

Result makeResult(Status s, std::string msg, uint64_t out) {
    Result r;
    r.status = s;
    r.message = std::move(msg);
    r.outputBytes = out;
    return r;
}

}  // namespace

Result VcdiffDecoder::run() {
    try {
        return runImpl();
    } catch (const std::bad_alloc&) {
        return makeResult(Status::OutOfMemory, "Memoria insuficiente para procesar el parche", 0);
    } catch (const std::exception& e) {
        return makeResult(Status::Internal, e.what(), 0);
    }
}

Result VcdiffDecoder::runImpl() {
    uint64_t outputBytes = 0;
    PatchReader rd(io_);
    const uint64_t patchSize = io_.patchSize();
    const uint64_t sourceSize = io_.sourceSize();
    const CodeTable& table = codeTable();

    auto fromReader = [&](const char* fallback) {
        Status s = rd.status() == Status::Ok ? Status::CorruptPatch : rd.status();
        return makeResult(s, rd.message().empty() ? fallback : rd.message(), outputBytes);
    };
    auto corrupt = [&](const char* msg) { return makeResult(Status::CorruptPatch, msg, outputBytes); };

    // ---- File header ------------------------------------------------------
    uint8_t magic[4];
    size_t got = rd.readSome(magic, 4);
    if (rd.status() == Status::PatchReadError) return fromReader("");
    if (got < 4 || magic[0] != 0xD6 || magic[1] != 0xC3 || magic[2] != 0xC4)
        return makeResult(Status::NotVcdiff, "El archivo no es un parche XDelta/VCDIFF", 0);
    if (magic[3] != 0)
        return makeResult(Status::Unsupported, "Versión de VCDIFF no soportada", 0);

    uint8_t hdrInd;
    if (!rd.readByte(hdrInd)) return fromReader("Cabecera del parche incompleta");
    if (hdrInd & ~0x07) return corrupt("Indicadores de cabecera inválidos");
    uint8_t secondaryId = 0;
    if ((hdrInd & 0x01) && !rd.readByte(secondaryId)) return fromReader("Cabecera del parche incompleta");
    if (hdrInd & 0x02)
        return makeResult(Status::Unsupported, "El parche usa una tabla de códigos personalizada (no soportado)", 0);
    if (hdrInd & 0x04) {
        uint64_t appLen;
        if (!rd.readVarint(appLen)) return fromReader("Cabecera del parche incompleta");
        if (appLen > (1u << 20) || !rd.skip(appLen)) return corrupt("Cabecera de aplicación inválida");
    }

    std::unique_ptr<uint8_t[]> target;
    size_t targetCap = 0;
    std::vector<uint8_t> addData, instData, addrData;
    AddressCache cache;

    if (!io_.onProgress(rd.consumed(), outputBytes))
        return makeResult(Status::Cancelled, "Cancelado", outputBytes);

    // ---- Windows ----------------------------------------------------------
    while (!rd.atCleanEnd()) {
        if (rd.status() != Status::Ok) return fromReader("");

        uint8_t winInd;
        if (!rd.readByte(winInd)) return fromReader("");
        if (winInd & ~0x07 || (winInd & kWinSource && winInd & kWinTarget))
            return corrupt("Indicador de ventana inválido");
        if (winInd & kWinTarget)
            return makeResult(Status::Unsupported, "Ventanas VCD_TARGET no soportadas", outputBytes);

        uint64_t srcLen = 0, srcPos = 0;
        if (winInd & kWinSource) {
            if (!rd.readVarint(srcLen) || !rd.readVarint(srcPos)) return fromReader("");
            if (srcLen > UINT64_MAX - srcPos) return corrupt("Segmento de origen inválido");
            if (sourceSize != kUnknownSize && srcPos + srcLen > sourceSize)
                return makeResult(Status::SourceTooSmall,
                                  "El archivo original es más pequeño de lo que espera el parche", outputBytes);
        }

        uint64_t deltaLen, targetLen, addLen, instLen, addrLen;
        if (!rd.readVarint(deltaLen)) return fromReader("");
        const uint64_t deltaStart = rd.consumed();
        uint8_t deltaInd;
        if (!rd.readVarint(targetLen) || !rd.readByte(deltaInd) || !rd.readVarint(addLen) ||
            !rd.readVarint(instLen) || !rd.readVarint(addrLen))
            return fromReader("");
        if (deltaInd & ~0x07) return corrupt("Indicador de delta inválido");

        uint32_t expectedAdler = 0;
        const bool hasAdler = (winInd & kWinAdler32) != 0;
        if (hasAdler) {
            uint8_t c[4];
            if (!rd.readBytes(c, 4)) return fromReader("");
            expectedAdler = (uint32_t(c[0]) << 24) | (uint32_t(c[1]) << 16) | (uint32_t(c[2]) << 8) | c[3];
        }

        if (targetLen > kMaxWindowBytes)
            return makeResult(Status::Unsupported, "Ventana de parche demasiado grande (>256 MiB)", outputBytes);
        const uint64_t headerBytes = rd.consumed() - deltaStart;
        if (deltaLen < headerBytes || addLen > UINT64_MAX / 4 || instLen > UINT64_MAX / 4 ||
            addrLen > UINT64_MAX / 4 || deltaLen - headerBytes != addLen + instLen + addrLen)
            return corrupt("Longitudes de ventana inconsistentes");
        if (addLen > kMaxWindowBytes || instLen > kMaxWindowBytes || addrLen > kMaxWindowBytes)
            return makeResult(Status::Unsupported, "Sección de parche demasiado grande", outputBytes);
        if (patchSize != kUnknownSize && deltaLen - headerBytes > patchSize - rd.consumed())
            return corrupt("El parche termina de forma inesperada (truncado)");

        addData.resize(addLen);
        instData.resize(instLen);
        addrData.resize(addrLen);
        if (!rd.readBytes(addData.data(), addLen) || !rd.readBytes(instData.data(), instLen) ||
            !rd.readBytes(addrData.data(), addrLen))
            return fromReader("");

        // Secondary compression of sections.
        struct Sec {
            std::vector<uint8_t>* v;
            uint8_t flag;
        } secs[3] = {{&addData, 0x01}, {&instData, 0x02}, {&addrData, 0x04}};
        for (auto& s : secs) {
            if (!(deltaInd & s.flag)) continue;
            if (secondaryId != kSecondaryLzma) {
                const char* name = secondaryId == kSecondaryDjw   ? "DJW"
                                   : secondaryId == kSecondaryFgk ? "FGK"
                                                                  : "desconocida";
                std::string msg = std::string("El parche usa compresión secundaria ") + name +
                                  " (no soportada; solo se admite sin compresión secundaria o LZMA)";
                return makeResult(Status::Unsupported, msg, outputBytes);
            }
            MemReader mr(*s.v);
            uint64_t usize;
            if (!mr.varint(usize) || usize > kMaxWindowBytes) return corrupt("Sección comprimida inválida");
            std::vector<uint8_t> decoded(usize);
            std::string err;
            LzmaResult lr = decodeLzmaSection(s.v->data() + mr.pos, s.v->size() - mr.pos, decoded.data(),
                                              decoded.size(), err);
            if (lr == LzmaResult::Unsupported) return makeResult(Status::Unsupported, "LZMA: " + err, outputBytes);
            if (lr != LzmaResult::Ok) return corrupt("Datos LZMA del parche dañados");
            s.v->swap(decoded);
        }

        if (targetLen > targetCap) {
            target.reset();
            target.reset(new uint8_t[targetLen]);
            targetCap = targetLen;
        }
        uint8_t* tgt = target.get();

        // ---- Execute instructions ----------------------------------------
        cache.reset();
        MemReader inst(instData), addrs(addrData);
        uint64_t pos = 0, addPos = 0;
        unsigned counter = 0;
        const uint64_t winBase = (winInd & kWinSource) ? srcLen : 0;

        while (inst.pos < inst.size) {
            if (++counter >= kInstructionsPerCancelCheck) {
                counter = 0;
                if (!io_.onProgress(rd.consumed(), outputBytes))
                    return makeResult(Status::Cancelled, "Cancelado", outputBytes);
            }
            uint8_t op;
            inst.byte(op);
            for (int slot = 0; slot < 2; slot++) {
                const Inst& in = slot == 0 ? table.e[op].first : table.e[op].second;
                if (in.type == kNoop) continue;
                uint64_t size = in.size;
                if (size == 0 && !inst.varint(size)) return corrupt("Instrucciones del parche dañadas");
                if (size > targetLen - pos) return corrupt("Instrucción fuera de la ventana");

                if (in.type == kAdd) {
                    if (size > addData.size() - addPos) return corrupt("Datos ADD insuficientes");
                    std::memcpy(tgt + pos, addData.data() + addPos, size);
                    addPos += size;
                } else if (in.type == kRun) {
                    if (addPos >= addData.size()) return corrupt("Datos RUN insuficientes");
                    std::memset(tgt + pos, addData[addPos++], size);
                } else {
                    uint64_t addr;
                    const uint64_t here = winBase + pos;
                    if (!cache.decode(here, in.mode, addrs, addr) || addr >= here)
                        return corrupt("Dirección COPY inválida");
                    uint64_t remaining = size, dst = pos;
                    while (remaining > 0) {
                        if (addr < winBase) {
                            uint64_t n = std::min(remaining, winBase - addr);
                            Status st = io_.readSource(srcPos + addr, tgt + dst, static_cast<size_t>(n));
                            if (st == Status::Cancelled) return makeResult(st, "Cancelado", outputBytes);
                            if (st != Status::Ok) {
                                const char* m = st == Status::SourceTooSmall
                                                    ? "El archivo original es más pequeño de lo que espera el parche"
                                                : st == Status::SourceNotSeekable
                                                    ? "El archivo original no permite acceso aleatorio"
                                                    : "Error de lectura del archivo original";
                                return makeResult(st, m, outputBytes);
                            }
                            addr += n;
                            dst += n;
                            remaining -= n;
                        } else {
                            uint64_t from = addr - winBase;
                            for (uint64_t i = 0; i < remaining; i++) tgt[dst + i] = tgt[from + i];
                            dst += remaining;
                            remaining = 0;
                        }
                    }
                }
                pos += size;
            }
        }
        if (pos != targetLen) return corrupt("La ventana decodificada no tiene el tamaño esperado");

        if (hasAdler && adler32(tgt, targetLen) != expectedAdler)
            return makeResult(Status::ChecksumMismatch,
                              "La suma de verificación no coincide: el archivo original no es el que espera el parche, o el parche está dañado",
                              outputBytes);

        // ---- Write window -------------------------------------------------
        for (uint64_t off = 0; off < targetLen;) {
            size_t n = static_cast<size_t>(std::min<uint64_t>(kWriteChunk, targetLen - off));
            Status ws = io_.writeOutput(tgt + off, n);
            if (ws != Status::Ok)
                return makeResult(ws, ws == Status::NoSpace ? "No hay espacio suficiente en el almacenamiento"
                                                            : "Error de escritura del archivo de salida",
                                  outputBytes);
            off += n;
            outputBytes += n;
            if (!io_.onProgress(rd.consumed(), outputBytes))
                return makeResult(Status::Cancelled, "Cancelado", outputBytes);
        }
    }
    if (rd.status() != Status::Ok) return fromReader("");
    io_.onProgress(rd.consumed(), outputBytes);
    return makeResult(Status::Ok, "", outputBytes);
}

}  // namespace jullpatch
