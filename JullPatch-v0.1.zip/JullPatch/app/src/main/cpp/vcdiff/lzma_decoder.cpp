#include "lzma_decoder.h"

#include <algorithm>
#include <cstring>
#include <vector>

namespace jullpatch {
namespace {

constexpr unsigned kNumBitModelTotalBits = 11;
constexpr unsigned kNumMoveBits = 5;
constexpr uint16_t kProbInit = 1u << (kNumBitModelTotalBits - 1);
constexpr unsigned kNumStates = 12;
constexpr unsigned kNumPosBitsMax = 4;
constexpr unsigned kNumLenToPosStates = 4;
constexpr unsigned kNumAlignBits = 4;
constexpr unsigned kEndPosModelIndex = 14;
constexpr unsigned kNumFullDistances = 1u << (kEndPosModelIndex >> 1);

struct RangeDecoder {
    const uint8_t* p = nullptr;
    const uint8_t* end = nullptr;
    uint32_t range = 0;
    uint32_t code = 0;
    bool error = false;

    bool init(const uint8_t* data, size_t size) {
        p = data;
        end = data + size;
        error = false;
        if (size < 5 || p[0] != 0) return false;
        code = (uint32_t(p[1]) << 24) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 8) | p[4];
        range = 0xFFFFFFFFu;
        p += 5;
        return code != range;
    }

    inline void normalize() {
        if (range < (1u << 24)) {
            range <<= 8;
            if (p >= end) {
                error = true;
                code <<= 8;
            } else {
                code = (code << 8) | *p++;
            }
        }
    }

    inline unsigned bit(uint16_t* prob) {
        unsigned v = *prob;
        uint32_t bound = (range >> kNumBitModelTotalBits) * v;
        unsigned sym;
        if (code < bound) {
            v += ((1u << kNumBitModelTotalBits) - v) >> kNumMoveBits;
            range = bound;
            sym = 0;
        } else {
            v -= v >> kNumMoveBits;
            code -= bound;
            range -= bound;
            sym = 1;
        }
        *prob = static_cast<uint16_t>(v);
        normalize();
        return sym;
    }

    uint32_t direct(unsigned numBits) {
        uint32_t res = 0;
        while (numBits--) {
            range >>= 1;
            code -= range;
            uint32_t t = 0u - (code >> 31);
            code += range & t;
            if (code == range) error = true;
            normalize();
            res = (res << 1) + t + 1;
        }
        return res;
    }

    unsigned bitTree(uint16_t* probs, unsigned numBits) {
        unsigned m = 1;
        for (unsigned i = 0; i < numBits; i++) m = (m << 1) + bit(probs + m);
        return m - (1u << numBits);
    }

    unsigned bitTreeReverse(uint16_t* probs, unsigned numBits) {
        unsigned m = 1, sym = 0;
        for (unsigned i = 0; i < numBits; i++) {
            unsigned b = bit(probs + m);
            m = (m << 1) + b;
            sym |= b << i;
        }
        return sym;
    }
};

struct LenDecoder {
    uint16_t choice, choice2;
    uint16_t low[1 << kNumPosBitsMax][8];
    uint16_t mid[1 << kNumPosBitsMax][8];
    uint16_t high[256];

    void reset() {
        choice = choice2 = kProbInit;
        for (auto& r : low) for (auto& v : r) v = kProbInit;
        for (auto& r : mid) for (auto& v : r) v = kProbInit;
        for (auto& v : high) v = kProbInit;
    }

    unsigned decode(RangeDecoder& rc, unsigned posState) {
        if (!rc.bit(&choice)) return rc.bitTree(low[posState], 3);
        if (!rc.bit(&choice2)) return 8 + rc.bitTree(mid[posState], 3);
        return 16 + rc.bitTree(high, 8);
    }
};

// Decoder working directly on the final output buffer: the buffer itself is the
// dictionary (the whole section is decoded in memory), so no sliding window.
class LzmaDecoder {
public:
    LzmaDecoder(uint8_t* out, size_t outSize) : out_(out), outSize_(outSize) {}

    bool setProps(uint8_t d) {
        if (d >= 9 * 5 * 5) return false;
        lc_ = d % 9;
        d /= 9;
        lp_ = d % 5;
        pb_ = d / 5;
        literal_.assign(size_t(0x300) << (lc_ + lp_), kProbInit);
        return true;
    }
    unsigned lc() const { return lc_; }
    unsigned lp() const { return lp_; }

    void resetState() {
        std::fill(literal_.begin(), literal_.end(), kProbInit);
        for (auto& v : isMatch_) v = kProbInit;
        for (auto& v : isRep0Long_) v = kProbInit;
        for (auto& v : isRep_) v = kProbInit;
        for (auto& v : isRepG0_) v = kProbInit;
        for (auto& v : isRepG1_) v = kProbInit;
        for (auto& v : isRepG2_) v = kProbInit;
        for (auto& r : posSlot_) for (auto& v : r) v = kProbInit;
        for (auto& v : posDecoders_) v = kProbInit;
        for (auto& v : align_) v = kProbInit;
        lenDec_.reset();
        repLenDec_.reset();
        state_ = 0;
        rep0_ = rep1_ = rep2_ = rep3_ = 0;
    }

    size_t pos() const { return pos_; }

    bool appendUncompressed(const uint8_t* src, size_t n) {
        if (n > outSize_ - pos_) return false;
        std::memcpy(out_ + pos_, src, n);
        pos_ += n;
        return true;
    }

    // Decodes exactly `count` bytes.
    bool decode(RangeDecoder& rc, size_t count) {
        if (count > outSize_ - pos_) return false;
        const size_t limit = pos_ + count;
        const unsigned pbMask = (1u << pb_) - 1;
        const unsigned lpMask = (1u << lp_) - 1;

        while (pos_ < limit) {
            if (rc.error) return false;
            const unsigned posState = unsigned(pos_) & pbMask;

            if (!rc.bit(&isMatch_[(state_ << kNumPosBitsMax) + posState])) {
                unsigned prev = pos_ ? out_[pos_ - 1] : 0;
                unsigned litState = ((unsigned(pos_) & lpMask) << lc_) + (prev >> (8 - lc_));
                uint16_t* probs = &literal_[size_t(0x300) * litState];
                unsigned symbol = 1;
                if (state_ >= 7) {
                    if (size_t(rep0_) + 1 > pos_) return false;
                    unsigned matchByte = out_[pos_ - rep0_ - 1];
                    do {
                        unsigned matchBit = (matchByte >> 7) & 1;
                        matchByte <<= 1;
                        unsigned b = rc.bit(&probs[((1 + matchBit) << 8) + symbol]);
                        symbol = (symbol << 1) | b;
                        if (matchBit != b) break;
                    } while (symbol < 0x100);
                }
                while (symbol < 0x100) symbol = (symbol << 1) | rc.bit(&probs[symbol]);
                out_[pos_++] = static_cast<uint8_t>(symbol);
                state_ = state_ < 4 ? 0 : (state_ < 10 ? state_ - 3 : state_ - 6);
                continue;
            }

            unsigned len;
            if (rc.bit(&isRep_[state_])) {
                if (pos_ == 0) return false;
                if (!rc.bit(&isRepG0_[state_])) {
                    if (!rc.bit(&isRep0Long_[(state_ << kNumPosBitsMax) + posState])) {
                        if (size_t(rep0_) + 1 > pos_) return false;
                        state_ = state_ < 7 ? 9 : 11;
                        out_[pos_] = out_[pos_ - rep0_ - 1];
                        pos_++;
                        continue;
                    }
                } else {
                    uint32_t dist;
                    if (!rc.bit(&isRepG1_[state_])) {
                        dist = rep1_;
                    } else {
                        if (!rc.bit(&isRepG2_[state_])) {
                            dist = rep2_;
                        } else {
                            dist = rep3_;
                            rep3_ = rep2_;
                        }
                        rep2_ = rep1_;
                    }
                    rep1_ = rep0_;
                    rep0_ = dist;
                }
                len = repLenDec_.decode(rc, posState);
                state_ = state_ < 7 ? 8 : 11;
            } else {
                rep3_ = rep2_;
                rep2_ = rep1_;
                rep1_ = rep0_;
                len = lenDec_.decode(rc, posState);
                state_ = state_ < 7 ? 7 : 10;
                rep0_ = decodeDistance(rc, len);
                if (rep0_ == 0xFFFFFFFFu) return false;  // end marker before expected size
            }

            len += 2;
            size_t dist = size_t(rep0_) + 1;
            if (dist > pos_ || len > limit - pos_) return false;
            const uint8_t* from = out_ + pos_ - dist;
            uint8_t* to = out_ + pos_;
            for (unsigned i = 0; i < len; i++) to[i] = from[i];
            pos_ += len;
        }
        return !rc.error;
    }

private:
    uint32_t decodeDistance(RangeDecoder& rc, unsigned len) {
        unsigned lenState = len < kNumLenToPosStates ? len : kNumLenToPosStates - 1;
        unsigned slot = rc.bitTree(posSlot_[lenState], 6);
        if (slot < 4) return slot;
        unsigned numDirect = (slot >> 1) - 1;
        uint32_t dist = (2u | (slot & 1)) << numDirect;
        if (slot < kEndPosModelIndex) {
            dist += rc.bitTreeReverse(posDecoders_ + dist - slot, numDirect);
        } else {
            dist += rc.direct(numDirect - kNumAlignBits) << kNumAlignBits;
            dist += rc.bitTreeReverse(align_, kNumAlignBits);
        }
        return dist;
    }

    uint8_t* out_;
    size_t outSize_;
    size_t pos_ = 0;
    unsigned lc_ = 0, lp_ = 0, pb_ = 0;
    unsigned state_ = 0;
    uint32_t rep0_ = 0, rep1_ = 0, rep2_ = 0, rep3_ = 0;
    std::vector<uint16_t> literal_;
    uint16_t isMatch_[kNumStates << kNumPosBitsMax];
    uint16_t isRep0Long_[kNumStates << kNumPosBitsMax];
    uint16_t isRep_[kNumStates], isRepG0_[kNumStates], isRepG1_[kNumStates], isRepG2_[kNumStates];
    uint16_t posSlot_[kNumLenToPosStates][64];
    uint16_t posDecoders_[1 + kNumFullDistances - kEndPosModelIndex];
    uint16_t align_[1u << kNumAlignBits];
    LenDecoder lenDec_, repLenDec_;
};

bool readXzVarint(const uint8_t* p, size_t size, size_t& pos, uint64_t& value) {
    value = 0;
    for (unsigned i = 0; i < 9; i++) {
        if (pos >= size) return false;
        uint8_t b = p[pos++];
        value |= uint64_t(b & 0x7F) << (7 * i);
        if (!(b & 0x80)) return true;
    }
    return false;
}

LzmaResult decodeAlone(const uint8_t* in, size_t inSize, uint8_t* out, size_t outSize,
                       std::string& error) {
    if (inSize < 13) {
        error = "LZMA header truncated";
        return LzmaResult::Corrupt;
    }
    uint64_t usize = 0;
    for (int i = 0; i < 8; i++) usize |= uint64_t(in[5 + i]) << (8 * i);
    if (usize != UINT64_MAX && usize < outSize) {
        error = "LZMA size mismatch";
        return LzmaResult::Corrupt;
    }
    LzmaDecoder dec(out, outSize);
    if (!dec.setProps(in[0])) {
        error = "invalid LZMA properties";
        return LzmaResult::Corrupt;
    }
    dec.resetState();
    RangeDecoder rc;
    if (!rc.init(in + 13, inSize - 13)) {
        error = "invalid LZMA stream start";
        return LzmaResult::Corrupt;
    }
    if (!dec.decode(rc, outSize)) {
        error = "corrupt LZMA data";
        return LzmaResult::Corrupt;
    }
    return LzmaResult::Ok;
}

LzmaResult decodeXz(const uint8_t* in, size_t inSize, uint8_t* out, size_t outSize,
                    std::string& error) {
    size_t p = 12;  // stream header: magic(6) + flags(2) + crc32(4)
    if (inSize < p + 12) {
        error = "XZ stream truncated";
        return LzmaResult::Corrupt;
    }
    const uint8_t hdrByte = in[p];
    if (hdrByte == 0) {
        error = "XZ stream has no blocks";
        return LzmaResult::Corrupt;
    }
    const size_t hdrSize = (size_t(hdrByte) + 1) * 4;
    if (p + hdrSize > inSize) {
        error = "XZ block header truncated";
        return LzmaResult::Corrupt;
    }
    const uint8_t flags = in[p + 1];
    if ((flags & 0x03) != 0) {
        error = "XZ chain of several filters";
        return LzmaResult::Unsupported;
    }
    size_t q = p + 2;
    const size_t hdrEnd = p + hdrSize;
    uint64_t v;
    if ((flags & 0x40) && !readXzVarint(in, hdrEnd, q, v)) return LzmaResult::Corrupt;
    if ((flags & 0x80) && !readXzVarint(in, hdrEnd, q, v)) return LzmaResult::Corrupt;
    uint64_t filterId, propsSize;
    if (!readXzVarint(in, hdrEnd, q, filterId) || !readXzVarint(in, hdrEnd, q, propsSize)) {
        error = "XZ filter header corrupt";
        return LzmaResult::Corrupt;
    }
    if (filterId != 0x21 || propsSize != 1) {
        error = "XZ filter is not LZMA2";
        return LzmaResult::Unsupported;
    }
    p = hdrEnd;

    LzmaDecoder dec(out, outSize);
    bool haveProps = false;
    for (;;) {
        if (p >= inSize) {
            error = "LZMA2 stream truncated";
            return LzmaResult::Corrupt;
        }
        const uint8_t ctrl = in[p++];
        if (ctrl == 0) break;
        if (ctrl == 1 || ctrl == 2) {
            if (p + 2 > inSize) {
                error = "LZMA2 chunk truncated";
                return LzmaResult::Corrupt;
            }
            size_t size = ((size_t(in[p]) << 8) | in[p + 1]) + 1;
            p += 2;
            if (size > inSize - p || !dec.appendUncompressed(in + p, size)) {
                error = "LZMA2 uncompressed chunk invalid";
                return LzmaResult::Corrupt;
            }
            p += size;
        } else if (ctrl >= 0x80) {
            if (p + 4 > inSize) {
                error = "LZMA2 chunk truncated";
                return LzmaResult::Corrupt;
            }
            size_t unpacked = ((size_t(ctrl & 0x1F) << 16) | (size_t(in[p]) << 8) | in[p + 1]) + 1;
            size_t packed = ((size_t(in[p + 2]) << 8) | in[p + 3]) + 1;
            p += 4;
            const unsigned mode = (ctrl >> 5) & 3;
            if (mode >= 2) {
                if (p >= inSize) {
                    error = "LZMA2 chunk truncated";
                    return LzmaResult::Corrupt;
                }
                if (!dec.setProps(in[p++]) || dec.lc() + dec.lp() > 4) {
                    error = "invalid LZMA2 properties";
                    return LzmaResult::Corrupt;
                }
                haveProps = true;
            }
            if (!haveProps) {
                error = "LZMA2 chunk without properties";
                return LzmaResult::Corrupt;
            }
            if (mode >= 1) dec.resetState();
            if (packed > inSize - p) {
                error = "LZMA2 chunk truncated";
                return LzmaResult::Corrupt;
            }
            RangeDecoder rc;
            if (!rc.init(in + p, packed) || !dec.decode(rc, unpacked)) {
                error = "corrupt LZMA2 data";
                return LzmaResult::Corrupt;
            }
            p += packed;
        } else {
            error = "invalid LZMA2 control byte";
            return LzmaResult::Corrupt;
        }
    }
    if (dec.pos() != outSize) {
        error = "LZMA2 output size mismatch";
        return LzmaResult::Corrupt;
    }
    return LzmaResult::Ok;
}

}  // namespace

LzmaResult decodeLzmaSection(const uint8_t* in, size_t inSize, uint8_t* out, size_t outSize,
                             std::string& error) {
    if (outSize == 0) return LzmaResult::Ok;
    static const uint8_t kXzMagic[6] = {0xFD, '7', 'z', 'X', 'Z', 0x00};
    if (inSize >= 6 && std::memcmp(in, kXzMagic, 6) == 0) return decodeXz(in, inSize, out, outSize, error);
    return decodeAlone(in, inSize, out, outSize, error);
}

}  // namespace jullpatch
