#include "fd_io.h"

#include <errno.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <cstring>

namespace jullpatch {
namespace {
uint64_t nowNs() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return uint64_t(ts.tv_sec) * 1000000000ull + uint64_t(ts.tv_nsec);
}
}  // namespace

FdIO::FdIO(int sourceFd, int patchFd, int outputFd, uint64_t sourceSize, uint64_t patchSize,
           ProgressFn progress, uint64_t minProgressIntervalNs)
    : sourceFd_(sourceFd),
      patchFd_(patchFd),
      outputFd_(outputFd),
      sourceSize_(sourceSize),
      patchSize_(patchSize),
      progress_(std::move(progress)),
      minIntervalNs_(minProgressIntervalNs) {}

ssize_t FdIO::readPatch(uint8_t* dst, size_t n) {
    for (;;) {
        ssize_t r = ::read(patchFd_, dst, n);
        if (r < 0 && errno == EINTR) continue;
        return r;
    }
}

Status FdIO::preadFully(uint64_t offset, uint8_t* dst, size_t n) {
    size_t done = 0;
    while (done < n) {
        ssize_t r = ::pread64(sourceFd_, dst + done, n - done, static_cast<off64_t>(offset + done));
        if (r < 0) {
            if (errno == EINTR) continue;
            if (errno == ESPIPE) return Status::SourceNotSeekable;
            return Status::SourceReadError;
        }
        if (r == 0) return Status::SourceTooSmall;
        done += static_cast<size_t>(r);
    }
    return Status::Ok;
}

Status FdIO::readSource(uint64_t offset, uint8_t* dst, size_t n) {
    if (n == 0) return Status::Ok;
    // Large reads bypass the cache.
    if (n >= kBlockSize / 4) return preadFully(offset, dst, n);

    size_t done = 0;
    while (done < n) {
        const uint64_t cur = offset + done;
        Block* hit = nullptr;
        for (auto& b : blocks_) {
            if (b.length > 0 && cur >= b.offset && cur < b.offset + b.length) {
                hit = &b;
                break;
            }
        }
        if (!hit) {
            Block* victim = &blocks_[0];
            for (auto& b : blocks_)
                if (b.lastUse < victim->lastUse) victim = &b;
            if (victim->data.empty()) victim->data.resize(kBlockSize);
            const uint64_t base = cur - (cur % kBlockSize);
            victim->length = 0;
            size_t got = 0;
            while (got < kBlockSize) {
                ssize_t r = ::pread64(sourceFd_, victim->data.data() + got, kBlockSize - got,
                                      static_cast<off64_t>(base + got));
                if (r < 0) {
                    if (errno == EINTR) continue;
                    if (errno == ESPIPE) return Status::SourceNotSeekable;
                    return Status::SourceReadError;
                }
                if (r == 0) break;  // EOF
                got += static_cast<size_t>(r);
            }
            victim->offset = base;
            victim->length = got;
            if (cur >= base + got) return Status::SourceTooSmall;
            hit = victim;
        }
        hit->lastUse = ++useCounter_;
        size_t inBlock = static_cast<size_t>(cur - hit->offset);
        size_t k = std::min(n - done, hit->length - inBlock);
        std::memcpy(dst + done, hit->data.data() + inBlock, k);
        done += k;
    }
    return Status::Ok;
}

Status FdIO::writeOutput(const uint8_t* src, size_t n) {
    size_t done = 0;
    while (done < n) {
        ssize_t w = ::write(outputFd_, src + done, n - done);
        if (w < 0) {
            if (errno == EINTR) continue;
            if (errno == ENOSPC || errno == EDQUOT || errno == EFBIG) return Status::NoSpace;
            return Status::OutputWriteError;
        }
        if (w == 0) return Status::OutputWriteError;
        done += static_cast<size_t>(w);
    }
    return Status::Ok;
}

bool FdIO::onProgress(uint64_t patchBytesRead, uint64_t outputBytes) {
    // Throttle callbacks into the host (JNI) to ~20 per second, but never skip
    // the very first one.
    uint64_t t = nowNs();
    if (lastProgressNs_ != 0 && t - lastProgressNs_ < minIntervalNs_) return true;
    lastProgressNs_ = t;
    return progress_ ? progress_(patchBytesRead, outputBytes) : true;
}

void FdIO::sync() { ::fsync(outputFd_); }

}  // namespace jullpatch
