#pragma once
#include <cstddef>
#include <cstdint>
#include <string>

namespace jullpatch {

enum class LzmaResult { Ok, Corrupt, Unsupported };

// Decodes an LZMA payload (as used by xdelta3 secondary compression) into a
// buffer whose exact decompressed size is already known. Accepts both the
// legacy ".lzma" (LZMA-alone) container and the ".xz" container with a single
// LZMA2 filter; the container is auto-detected.
LzmaResult decodeLzmaSection(const uint8_t* in, size_t inSize, uint8_t* out,
                             size_t outSize, std::string& error);

}  // namespace jullpatch
