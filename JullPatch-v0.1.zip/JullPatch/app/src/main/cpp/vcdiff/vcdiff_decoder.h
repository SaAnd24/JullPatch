#pragma once
#include "patch_io.h"
#include "status.h"

namespace jullpatch {

// Streaming VCDIFF (RFC 3284) decoder, i.e. the format of ".xdelta" files.
//
// Supported: default code table, ADD/RUN/COPY, all address modes, multiple
// windows, VCD_SOURCE windows, Adler-32 window checksums (xdelta3 extension),
// application header, secondary compression "none" and LZMA.
// Not supported (reported as Status::Unsupported): VCD_TARGET windows, custom
// code tables, DJW/FGK secondary compression.
//
// Memory use is bounded by the largest target window of the patch (xdelta3
// default: 8 MiB) plus its instruction sections; the source is never loaded
// into memory, it is read on demand through PatchIO::readSource.
class VcdiffDecoder {
public:
    explicit VcdiffDecoder(PatchIO& io) : io_(io) {}
    Result run();

private:
    Result runImpl();
    PatchIO& io_;
};

}  // namespace jullpatch
