package com.jullpatch.app.domain.model

import android.net.Uri

/** A file chosen through the Storage Access Framework. Never a filesystem path. */
data class FileRef(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long?,
)

data class PatchRequest(
    val source: FileRef,
    val patch: FileRef,
    val output: FileRef,
)

enum class PatchErrorKind {
    SOURCE_NOT_FOUND,
    SOURCE_UNREADABLE,
    PATCH_NOT_FOUND,
    PATCH_UNREADABLE,
    OUTPUT_UNWRITABLE,
    OUTPUT_SAME_AS_INPUT,
    NOT_A_PATCH,
    PATCH_CORRUPT,
    UNSUPPORTED_PATCH,
    SOURCE_MISMATCH,
    SOURCE_TOO_SMALL,
    SOURCE_NOT_SEEKABLE,
    READ_ERROR,
    WRITE_ERROR,
    NO_SPACE,
    OUT_OF_MEMORY,
    UNEXPECTED,
}

data class PatchFailure(
    val kind: PatchErrorKind,
    /** Raw detail for diagnostics; not meant as the primary user message. */
    val technicalDetail: String? = null,
)

enum class PatchStage { OPENING, PATCHING, CANCELLING }

data class PatchProgress(
    val stage: PatchStage,
    val fileName: String,
    val patchBytesRead: Long = 0L,
    val patchTotalBytes: Long? = null,
    val outputBytes: Long = 0L,
) {
    /**
     * Real progress: fraction of the patch file already consumed by the decoder.
     * Null when the patch size is unknown.
     */
    val fraction: Float?
        get() {
            val total = patchTotalBytes ?: return null
            if (total <= 0L) return null
            return (patchBytesRead.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
        }
}

sealed interface PatchOutcome {
    data class Success(
        val output: FileRef,
        val outputBytes: Long,
        val elapsedMillis: Long,
    ) : PatchOutcome

    data class Failure(val failure: PatchFailure) : PatchOutcome

    data object Cancelled : PatchOutcome
}
