package com.jullpatch.app.ui

import android.net.Uri
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.jullpatch.app.AppContainer
import com.jullpatch.app.domain.files.FileAccessException
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.files.FileRole
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.PatchErrorKind
import com.jullpatch.app.domain.model.PatchOutcome
import com.jullpatch.app.domain.model.PatchRequest
import com.jullpatch.app.service.JobState
import com.jullpatch.app.service.PatchJobManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen { HOME, FORM }

data class MainUiState(
    val screen: Screen = Screen.HOME,
    val source: FileRef? = null,
    val patch: FileRef? = null,
    val output: FileRef? = null,
    @StringRes val messageRes: Int? = null,
    val job: JobState = JobState.Idle,
) {
    val canApply: Boolean get() = source != null && patch != null && output != null
    val suggestedOutputName: String get() = source?.name?.let(::suggestOutputName) ?: "parcheado.bin"
}

class MainViewModel(
    private val files: FileGateway,
    private val jobs: PatchJobManager,
) : ViewModel() {

    private data class Local(
        val screen: Screen = Screen.HOME,
        val source: FileRef? = null,
        val patch: FileRef? = null,
        val output: FileRef? = null,
        @StringRes val messageRes: Int? = null,
    )

    private val local = MutableStateFlow(Local())

    val uiState: StateFlow<MainUiState> = combine(local, jobs.state) { l, j -> toUi(l, j) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, toUi(local.value, jobs.state.value))

    private fun toUi(l: Local, j: JobState) = MainUiState(
        screen = l.screen,
        source = l.source,
        patch = l.patch,
        output = l.output,
        messageRes = l.messageRes,
        job = j,
    )

    fun openForm() = local.update { it.copy(screen = Screen.FORM, messageRes = null) }

    fun backToHome() = local.update { it.copy(screen = Screen.HOME, messageRes = null) }

    fun onSourcePicked(uri: Uri) = describeAndStore(uri, FileRole.SOURCE) { l, f -> l.copy(source = f) }

    fun onPatchPicked(uri: Uri) = describeAndStore(uri, FileRole.PATCH) { l, f -> l.copy(patch = f) }

    fun onOutputPicked(uri: Uri) = describeAndStore(uri, FileRole.OUTPUT) { l, f -> l.copy(output = f) }

    private fun describeAndStore(uri: Uri, role: FileRole, transform: (Local, FileRef) -> Local) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { files.describe(uri, role) } }
            result.onSuccess { ref ->
                local.update { transform(it, ref).copy(messageRes = null) }
            }.onFailure { e ->
                val kind = (e as? FileAccessException)?.kind ?: PatchErrorKind.UNEXPECTED
                local.update { it.copy(messageRes = kind.messageRes()) }
            }
        }
    }

    fun startPatch() {
        val l = local.value
        val source = l.source
        val patch = l.patch
        val output = l.output
        if (source == null || patch == null || output == null) return
        if (output.uri == source.uri || output.uri == patch.uri) {
            local.update { it.copy(messageRes = PatchErrorKind.OUTPUT_SAME_AS_INPUT.messageRes()) }
            return
        }
        local.update { it.copy(messageRes = null) }
        jobs.start(PatchRequest(source, patch, output))
    }

    fun cancelPatch() = jobs.cancel()

    /** "Volver" on a result screen. */
    fun dismissResult() {
        val finished = jobs.state.value as? JobState.Finished ?: return
        jobs.reset()
        local.update {
            when (finished.outcome) {
                is PatchOutcome.Success -> Local() // start fresh at the home screen
                // The output document was deleted; keep inputs so the user can retry.
                else -> it.copy(screen = Screen.FORM, output = null, messageRes = null)
            }
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer { MainViewModel(container.fileGateway, container.jobManager) }
        }
    }
}
