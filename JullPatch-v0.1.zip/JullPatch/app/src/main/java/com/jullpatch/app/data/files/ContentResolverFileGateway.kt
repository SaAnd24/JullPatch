package com.jullpatch.app.data.files

import android.content.ContentResolver
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.jullpatch.app.domain.files.FileAccessException
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.files.FileRole
import com.jullpatch.app.domain.files.OpenedFile
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.PatchErrorKind
import java.io.FileNotFoundException
import java.io.IOException

/** Storage Access Framework implementation: only content:// URIs, no absolute paths. */
class ContentResolverFileGateway(private val resolver: ContentResolver) : FileGateway {

    override fun describe(uri: Uri, role: FileRole): FileRef {
        var name: String? = null
        var size: Long? = null
        try {
            resolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null,
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0 && !cursor.isNull(nameIdx)) name = cursor.getString(nameIdx)
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
                }
            }
        } catch (e: SecurityException) {
            throw FileAccessException(unreadableKind(role), e)
        } catch (e: IllegalArgumentException) {
            throw FileAccessException(notFoundKind(role), e)
        } catch (e: RuntimeException) {
            throw FileAccessException(unreadableKind(role), e)
        }
        return FileRef(uri, name ?: uri.lastPathSegment ?: "archivo", size)
    }

    override fun openForRead(uri: Uri, role: FileRole): OpenedFile {
        val pfd = try {
            resolver.openFileDescriptor(uri, "r")
        } catch (e: FileNotFoundException) {
            val msg = e.message.orEmpty()
            val denied = msg.contains("EACCES", ignoreCase = true) || msg.contains("permission", ignoreCase = true)
            throw FileAccessException(if (denied) unreadableKind(role) else notFoundKind(role), e)
        } catch (e: SecurityException) {
            throw FileAccessException(unreadableKind(role), e)
        } catch (e: RuntimeException) {
            throw FileAccessException(unreadableKind(role), e)
        } ?: throw FileAccessException(unreadableKind(role))
        return PfdOpenedFile(pfd)
    }

    override fun openForWrite(uri: Uri): OpenedFile {
        val pfd = try {
            openWriteTruncating(uri)
        } catch (e: SecurityException) {
            throw FileAccessException(PatchErrorKind.OUTPUT_UNWRITABLE, e)
        } catch (e: IOException) {
            throw FileAccessException(PatchErrorKind.OUTPUT_UNWRITABLE, e)
        } catch (e: RuntimeException) {
            throw FileAccessException(PatchErrorKind.OUTPUT_UNWRITABLE, e)
        } ?: throw FileAccessException(PatchErrorKind.OUTPUT_UNWRITABLE)
        return PfdOpenedFile(pfd)
    }

    /** Some providers reject the truncate flag ("wt"); the freshly created document is empty anyway. */
    private fun openWriteTruncating(uri: Uri): ParcelFileDescriptor? = try {
        resolver.openFileDescriptor(uri, "wt")
    } catch (e: FileNotFoundException) {
        resolver.openFileDescriptor(uri, "w")
    } catch (e: IllegalArgumentException) {
        resolver.openFileDescriptor(uri, "w")
    } catch (e: UnsupportedOperationException) {
        resolver.openFileDescriptor(uri, "w")
    }

    override fun querySize(uri: Uri): Long? = try {
        resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
        }
    } catch (e: RuntimeException) {
        null
    }

    override fun delete(uri: Uri): Boolean = try {
        DocumentsContract.deleteDocument(resolver, uri) || resolver.delete(uri, null, null) > 0
    } catch (e: Exception) {
        try {
            resolver.delete(uri, null, null) > 0
        } catch (e2: Exception) {
            false
        }
    }

    private fun notFoundKind(role: FileRole) = when (role) {
        FileRole.SOURCE -> PatchErrorKind.SOURCE_NOT_FOUND
        FileRole.PATCH -> PatchErrorKind.PATCH_NOT_FOUND
        FileRole.OUTPUT -> PatchErrorKind.OUTPUT_UNWRITABLE
    }

    private fun unreadableKind(role: FileRole) = when (role) {
        FileRole.SOURCE -> PatchErrorKind.SOURCE_UNREADABLE
        FileRole.PATCH -> PatchErrorKind.PATCH_UNREADABLE
        FileRole.OUTPUT -> PatchErrorKind.OUTPUT_UNWRITABLE
    }

    private class PfdOpenedFile(private val pfd: ParcelFileDescriptor) : OpenedFile {
        override val fd: Int get() = pfd.fd
        override val sizeBytes: Long? get() = pfd.statSize.takeIf { it >= 0L }
        override fun close() {
            try {
                pfd.close()
            } catch (e: IOException) {
                // Nothing useful can be done if closing fails.
            }
        }
    }
}
