package com.jullpatch.app.ui

import java.util.Locale

/** Formats a byte count using binary multiples (1 KB = 1024 B), e.g. "4.37 GB". */
fun formatBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = -1
    while (value >= 1024.0 && unit < units.lastIndex) {
        value /= 1024.0
        unit++
    }
    return String.format(Locale.getDefault(), "%.2f %s", value, units[unit])
}

fun formatPercent(fraction: Float): String = "${(fraction * 100f).toInt().coerceIn(0, 100)}%"

fun formatDuration(millis: Long): String {
    val totalSeconds = millis / 1000
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return when {
        h > 0 -> String.format(Locale.getDefault(), "%d h %02d min %02d s", h, m, s)
        m > 0 -> String.format(Locale.getDefault(), "%d min %02d s", m, s)
        totalSeconds > 0 -> "$totalSeconds s"
        else -> "<1 s"
    }
}

/** Suggests an output name such as "game.iso" -> "game_patched.iso". */
fun suggestOutputName(sourceName: String): String {
    val dot = sourceName.lastIndexOf('.')
    return if (dot > 0) {
        sourceName.substring(0, dot) + "_patched" + sourceName.substring(dot)
    } else {
        sourceName + "_patched"
    }
}
