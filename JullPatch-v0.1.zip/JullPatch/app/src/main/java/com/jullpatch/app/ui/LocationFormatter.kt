package com.jullpatch.app.ui

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.jullpatch.app.R

/** Turns a SAF document URI into something a person can read. Falls back to the provider name. */
fun describeLocation(context: Context, uri: Uri): String {
    return try {
        if (!DocumentsContract.isDocumentUri(context, uri)) {
            return context.getString(R.string.location_other, uri.authority ?: uri.toString())
        }
        val docId = DocumentsContract.getDocumentId(uri)
        when (uri.authority) {
            "com.android.externalstorage.documents" -> {
                val volume = docId.substringBefore(':')
                val path = docId.substringAfter(':', "")
                val root = if (volume == "primary") {
                    context.getString(R.string.location_internal)
                } else {
                    context.getString(R.string.location_volume, volume)
                }
                if (path.isEmpty()) root else "$root › ${path.replace("/", " › ")}"
            }
            "com.android.providers.downloads.documents" ->
                context.getString(R.string.location_downloads)
            else -> context.getString(R.string.location_other, uri.authority ?: docId)
        }
    } catch (e: IllegalArgumentException) {
        context.getString(R.string.location_other, uri.authority ?: uri.toString())
    }
}
