package com.jullpatch.app.domain.engine

import com.jullpatch.app.domain.files.OpenedFile
import com.jullpatch.app.domain.model.PatchFailure

fun interface EngineListener {
    /**
     * @param patchBytesRead bytes of the patch consumed so far.
     * @param outputBytes bytes already written to the output.
     * @return false to request cancellation.
     */
    fun onProgress(patchBytesRead: Long, outputBytes: Long): Boolean
}

sealed interface EngineResult {
    data class Success(val outputBytes: Long) : EngineResult
    data class Failure(val failure: PatchFailure) : EngineResult
    data object Cancelled : EngineResult
}

/**
 * A patch-format engine. Implementations stream from [source] and [patch] and write
 * sequentially to [output]; they must not load whole files into memory and must
 * not close the given files.
 */
interface PatchEngine {
    fun apply(
        source: OpenedFile,
        patch: OpenedFile,
        output: OpenedFile,
        listener: EngineListener,
    ): EngineResult
}
