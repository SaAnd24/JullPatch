package com.jullpatch.app.service

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ProcessLifecycleOwner
import com.jullpatch.app.JullPatchApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Keeps the process in the foreground (and the CPU awake) while a patch job runs, so that
 * multi-GB patches survive the user leaving the app or turning the screen off.
 * The job itself lives in [PatchJobManager]; this service only mirrors its state into a notification.
 */
class PatchForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var observer: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val manager = (application as JullPatchApp).container.jobManager

        if (intent?.action == ACTION_CANCEL) {
            manager.cancel()
        }

        val initial = manager.state.value as? JobState.Running
        ServiceCompat.startForeground(
            this,
            PatchNotifications.ID_PROGRESS,
            PatchNotifications.running(this, initial),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
        acquireWakeLock()

        if (observer == null) {
            observer = serviceScope.launch {
                manager.state.collect { state ->
                    when (state) {
                        is JobState.Running -> {
                            getSystemService(NotificationManager::class.java)
                                .notify(PatchNotifications.ID_PROGRESS, PatchNotifications.running(this@PatchForegroundService, state))
                        }
                        is JobState.Finished -> {
                            finish(state)
                        }
                        JobState.Idle -> {
                            stopSelfCleanly()
                        }
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun finish(state: JobState.Finished) {
        val appVisible = ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        stopSelfCleanly()
        if (!appVisible) {
            getSystemService(NotificationManager::class.java).notify(
                PatchNotifications.ID_RESULT,
                PatchNotifications.result(this, state.outcome, state.request.source.name),
            )
        }
    }

    private fun stopSelfCleanly() {
        releaseWakeLock()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    @SuppressLint("WakelockTimeout")
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "JullPatch:patching").apply {
            acquire(WAKE_LOCK_TIMEOUT_MS)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    override fun onDestroy() {
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_CANCEL = "com.jullpatch.app.action.CANCEL"
        private const val WAKE_LOCK_TIMEOUT_MS = 6L * 60 * 60 * 1000

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, PatchForegroundService::class.java))
            } catch (e: RuntimeException) {
                // Starting a foreground service can be refused (e.g. app not in the foreground).
                // The job still runs in-process; only the background-survival guarantee is lost.
            }
        }
    }
}
