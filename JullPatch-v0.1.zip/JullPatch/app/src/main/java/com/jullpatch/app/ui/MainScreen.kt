package com.jullpatch.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.jullpatch.app.R
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.PatchOutcome
import com.jullpatch.app.domain.model.PatchStage
import com.jullpatch.app.service.JobState

/** Callbacks the screen needs; the Activity wires file pickers and the ViewModel behind them. */
class MainActions(
    val onOpenForm: () -> Unit,
    val onBackToHome: () -> Unit,
    val onPickSource: () -> Unit,
    val onPickPatch: () -> Unit,
    val onPickOutput: () -> Unit,
    val onApply: () -> Unit,
    val onCancel: () -> Unit,
    val onDismissResult: () -> Unit,
)

@Composable
fun MainScreen(state: MainUiState, actions: MainActions) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when (val job = state.job) {
                is JobState.Running -> ProgressContent(job, actions)
                is JobState.Finished -> ResultContent(job, actions)
                JobState.Idle -> when (state.screen) {
                    Screen.HOME -> HomeContent(actions)
                    Screen.FORM -> FormContent(state, actions)
                }
            }
        }
    }
}

@Composable
private fun HomeContent(actions: MainActions) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.home_tagline),
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = actions.onOpenForm,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
        ) {
            Text(stringResource(R.string.action_apply_xdelta), style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            text = stringResource(R.string.version_label),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.outline,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FormContent(state: MainUiState, actions: MainActions) {
    BackHandler(onBack = actions.onBackToHome)
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(stringResource(R.string.form_title)) },
            windowInsets = WindowInsets(0, 0, 0, 0),
            navigationIcon = {
                IconButton(onClick = actions.onBackToHome) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back_description))
                }
            },
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            FileSlot(
                title = stringResource(R.string.slot_source_title),
                hint = stringResource(R.string.slot_source_hint),
                file = state.source,
                onClick = actions.onPickSource,
            )
            FileSlot(
                title = stringResource(R.string.slot_patch_title),
                hint = stringResource(R.string.slot_patch_hint),
                file = state.patch,
                onClick = actions.onPickPatch,
            )
            FileSlot(
                title = stringResource(R.string.slot_output_title),
                hint = stringResource(R.string.slot_output_hint),
                file = state.output,
                onClick = actions.onPickOutput,
                showSize = false,
            )
            state.messageRes?.let {
                Text(
                    text = stringResource(it),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
        Button(
            onClick = actions.onApply,
            enabled = state.canApply,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .height(56.dp),
        ) {
            Text(stringResource(R.string.action_apply), style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun FileSlot(
    title: String,
    hint: String,
    file: FileRef?,
    onClick: () -> Unit,
    showSize: Boolean = true,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            if (file == null) {
                Text(hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text(file.name, style = MaterialTheme.typography.titleMedium)
                val size = file.sizeBytes
                if (showSize && size != null) {
                    Text(formatBytes(size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun ProgressContent(job: JobState.Running, actions: MainActions) {
    val progress = job.progress
    val fraction = progress.fraction
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            stringResource(R.string.progress_title),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            when (progress.stage) {
                PatchStage.OPENING -> stringResource(R.string.stage_opening)
                PatchStage.PATCHING -> stringResource(R.string.stage_patching)
                PatchStage.CANCELLING -> stringResource(R.string.stage_cancelling)
            },
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.progress_file, progress.fileName), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))

        if (fraction != null && progress.stage == PatchStage.PATCHING) {
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text(formatPercent(fraction), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        } else {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.progress_written, formatBytes(progress.outputBytes)),
            style = MaterialTheme.typography.bodyMedium,
        )
        val total = progress.patchTotalBytes
        if (total != null && total > 0L) {
            Text(
                stringResource(R.string.progress_patch_read, formatBytes(progress.patchBytesRead), formatBytes(total)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(32.dp))
        OutlinedButton(
            onClick = actions.onCancel,
            enabled = !job.cancelling,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(stringResource(if (job.cancelling) R.string.action_cancelling else R.string.action_cancel))
        }
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.progress_cancel_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
        )
    }
}

@Composable
private fun ResultContent(job: JobState.Finished, actions: MainActions) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        when (val outcome = job.outcome) {
            is PatchOutcome.Success -> {
                Icon(
                    Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(72.dp),
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    stringResource(R.string.success_title),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(24.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        ResultRow(stringResource(R.string.result_file), outcome.output.name)
                        ResultRow(stringResource(R.string.result_location), describeLocation(context, outcome.output.uri))
                        ResultRow(stringResource(R.string.result_size), formatBytes(outcome.outputBytes))
                        ResultRow(stringResource(R.string.result_time), formatDuration(outcome.elapsedMillis))
                    }
                }
            }
            is PatchOutcome.Failure -> {
                Icon(
                    Icons.Filled.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(72.dp),
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    stringResource(R.string.failure_title),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    stringResource(outcome.failure.kind.messageRes()),
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                )
                outcome.failure.technicalDetail?.let { detail ->
                    Spacer(Modifier.height(12.dp))
                    Text(
                        stringResource(R.string.failure_technical, detail),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline,
                        textAlign = TextAlign.Center,
                    )
                }
            }
            PatchOutcome.Cancelled -> {
                Icon(
                    Icons.Filled.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(72.dp),
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    stringResource(R.string.cancelled_title),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    stringResource(R.string.cancelled_body),
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                )
            }
        }
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = actions.onDismissResult,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
        ) {
            Text(stringResource(R.string.action_back), style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun ResultRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
