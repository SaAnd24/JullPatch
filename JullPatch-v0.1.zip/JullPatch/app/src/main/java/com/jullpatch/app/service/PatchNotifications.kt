package com.jullpatch.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.jullpatch.app.MainActivity
import com.jullpatch.app.R
import com.jullpatch.app.domain.model.PatchOutcome

object PatchNotifications {
    const val CHANNEL_PROGRESS = "patch_progress"
    const val CHANNEL_RESULT = "patch_result"
    const val ID_PROGRESS = 1001
    const val ID_RESULT = 1002

    fun createChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_PROGRESS,
                context.getString(R.string.notif_channel_progress),
                NotificationManager.IMPORTANCE_LOW,
            ),
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_RESULT,
                context.getString(R.string.notif_channel_result),
                NotificationManager.IMPORTANCE_DEFAULT,
            ),
        )
    }

    fun running(context: Context, state: JobState.Running?): Notification {
        val builder = NotificationCompat.Builder(context, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.notif_progress_title))
            .setContentIntent(openAppIntent(context))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        if (state != null) {
            builder.setContentText(state.progress.fileName)
            val fraction = state.progress.fraction
            if (fraction != null) {
                builder.setProgress(100, (fraction * 100).toInt(), false)
            } else {
                builder.setProgress(0, 0, true)
            }
            if (!state.cancelling) {
                val cancel = PendingIntent.getService(
                    context,
                    0,
                    Intent(context, PatchForegroundService::class.java).setAction(PatchForegroundService.ACTION_CANCEL),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
                builder.addAction(0, context.getString(R.string.action_cancel), cancel)
            }
        } else {
            builder.setProgress(0, 0, true)
        }
        return builder.build()
    }

    fun result(context: Context, outcome: PatchOutcome, fileName: String): Notification {
        val title = when (outcome) {
            is PatchOutcome.Success -> R.string.notif_done_title
            is PatchOutcome.Failure -> R.string.notif_failed_title
            PatchOutcome.Cancelled -> R.string.notif_cancelled_title
        }
        return NotificationCompat.Builder(context, CHANNEL_RESULT)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(title))
            .setContentText(fileName)
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .build()
    }

    private fun openAppIntent(context: Context): PendingIntent = PendingIntent.getActivity(
        context,
        0,
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
}
