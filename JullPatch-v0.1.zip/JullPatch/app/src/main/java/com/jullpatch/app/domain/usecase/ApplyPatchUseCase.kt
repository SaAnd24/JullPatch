package com.jullpatch.app.domain.usecase

import com.jullpatch.app.domain.engine.EngineResult
import com.jullpatch.app.domain.engine.PatchEngine
import com.jullpatch.app.domain.files.FileAccessException
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.files.FileRole
import com.jullpatch.app.domain.files.OpenedFile
import com.jullpatch.app.domain.model.PatchErrorKind
import com.jullpatch.app.domain.model.PatchFailure
import com.jullpatch.app.domain.model.PatchOutcome
import com.jullpatch.app.domain.model.PatchProgress
import com.jullpatch.app.domain.model.PatchRequest
import com.jullpatch.app.domain.model.PatchStage

/**
 * Orchestrates one patch run: opens the files, runs the engine, and guarantees that no
 * half-written output is left behind on failure or cancellation.
 *
 * Blocking: call from a background dispatcher.
 */
class ApplyPatchUseCase(
    private val files: FileGateway,
    private val engine: PatchEngine,
) {

    fun execute(
        request: PatchRequest,
        isCancelled: () -> Boolean,
        onProgress: (PatchProgress) -> Unit,
    ): PatchOutcome {
        if (request.output.uri == request.source.uri || request.output.uri == request.patch.uri) {
            return PatchOutcome.Failure(PatchFailure(PatchErrorKind.OUTPUT_SAME_AS_INPUT))
        }

        val startedAt = System.currentTimeMillis()
        val fileName = request.source.name
        onProgress(PatchProgress(PatchStage.OPENING, fileName, patchTotalBytes = request.patch.sizeBytes))

        var source: OpenedFile? = null
        var patch: OpenedFile? = null
        var output: OpenedFile? = null
        val result: EngineResult = try {
            val src = files.openForRead(request.source.uri, FileRole.SOURCE)
            source = src
            val pch = files.openForRead(request.patch.uri, FileRole.PATCH)
            patch = pch
            val out = files.openForWrite(request.output.uri)
            output = out

            val patchTotal = pch.sizeBytes ?: request.patch.sizeBytes
            onProgress(PatchProgress(PatchStage.PATCHING, fileName, 0L, patchTotal, 0L))

            engine.apply(src, pch, out) { patchBytes, outputBytes ->
                if (isCancelled()) {
                    false
                } else {
                    onProgress(PatchProgress(PatchStage.PATCHING, fileName, patchBytes, patchTotal, outputBytes))
                    true
                }
            }
        } catch (e: FileAccessException) {
            EngineResult.Failure(PatchFailure(e.kind, e.message))
        } catch (e: Throwable) {
            EngineResult.Failure(PatchFailure(PatchErrorKind.UNEXPECTED, e.toString()))
        } finally {
            output?.close()
            patch?.close()
            source?.close()
        }

        return when (result) {
            is EngineResult.Success -> {
                val size = files.querySize(request.output.uri)?.takeIf { it > 0L } ?: result.outputBytes
                PatchOutcome.Success(
                    output = request.output.copy(sizeBytes = size),
                    outputBytes = size,
                    elapsedMillis = System.currentTimeMillis() - startedAt,
                )
            }
            is EngineResult.Cancelled -> {
                files.delete(request.output.uri)
                PatchOutcome.Cancelled
            }
            is EngineResult.Failure -> {
                files.delete(request.output.uri)
                PatchOutcome.Failure(result.failure)
            }
        }
    }
}
