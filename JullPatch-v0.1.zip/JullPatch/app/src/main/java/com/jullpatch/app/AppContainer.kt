package com.jullpatch.app

import android.app.Application
import com.jullpatch.app.data.engine.XdeltaPatchEngine
import com.jullpatch.app.data.files.ContentResolverFileGateway
import com.jullpatch.app.domain.engine.PatchEngine
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.usecase.ApplyPatchUseCase
import com.jullpatch.app.service.PatchJobManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Manual dependency container. Swap [engine] to plug in other patch formats later. */
class AppContainer(application: Application) {
    val fileGateway: FileGateway = ContentResolverFileGateway(application.contentResolver)
    val engine: PatchEngine = XdeltaPatchEngine()
    val applyPatch = ApplyPatchUseCase(fileGateway, engine)
    val jobManager = PatchJobManager(
        appContext = application,
        useCase = applyPatch,
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
    )
}
