package com.jullpatch.app.domain.files

import android.net.Uri
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.PatchErrorKind
import java.io.Closeable

enum class FileRole { SOURCE, PATCH, OUTPUT }

/** An open file exposed as a raw descriptor so the native engine can stream it. */
interface OpenedFile : Closeable {
    val fd: Int

    /** Size reported by fstat, or null when it cannot be determined. */
    val sizeBytes: Long?
}

class FileAccessException(
    val kind: PatchErrorKind,
    cause: Throwable? = null,
) : Exception(cause?.message ?: kind.name, cause)

/** Abstraction over file access so the patch logic never depends on Android storage APIs. */
interface FileGateway {
    fun describe(uri: Uri, role: FileRole): FileRef
    fun openForRead(uri: Uri, role: FileRole): OpenedFile
    fun openForWrite(uri: Uri): OpenedFile
    fun querySize(uri: Uri): Long?
    fun delete(uri: Uri): Boolean
}
