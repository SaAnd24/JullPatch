package com.jullpatch.app.data.engine

import com.jullpatch.app.domain.engine.EngineListener
import com.jullpatch.app.domain.engine.EngineResult
import com.jullpatch.app.domain.engine.PatchEngine
import com.jullpatch.app.domain.files.OpenedFile
import com.jullpatch.app.domain.model.PatchErrorKind
import com.jullpatch.app.domain.model.PatchFailure

/** [PatchEngine] backed by the native VCDIFF decoder (the format of ".xdelta" files). */
class XdeltaPatchEngine : PatchEngine {

    override fun apply(
        source: OpenedFile,
        patch: OpenedFile,
        output: OpenedFile,
        listener: EngineListener,
    ): EngineResult {
        var nativeMessage: String? = null
        var lastOutputBytes = 0L

        val bridge = object : NativeXdelta.Listener {
            override fun onProgress(patchBytesRead: Long, outputBytes: Long): Boolean {
                lastOutputBytes = outputBytes
                return listener.onProgress(patchBytesRead, outputBytes)
            }

            override fun onMessage(message: String) {
                nativeMessage = message
            }
        }

        val code = try {
            NativeXdelta.nativeApply(
                sourceFd = source.fd,
                patchFd = patch.fd,
                outputFd = output.fd,
                sourceSize = source.sizeBytes ?: -1L,
                patchSize = patch.sizeBytes ?: -1L,
                listener = bridge,
            )
        } catch (e: LinkageError) {
            // Native library missing for this ABI, or failed to initialise.
            return EngineResult.Failure(PatchFailure(PatchErrorKind.UNEXPECTED, "Motor nativo no disponible: ${e.message}"))
        }

        val detail = nativeMessage
        return when (code) {
            NativeStatus.OK -> EngineResult.Success(output.sizeBytes ?: lastOutputBytes)
            NativeStatus.CANCELLED -> EngineResult.Cancelled
            else -> EngineResult.Failure(PatchFailure(code.toErrorKind(), detail))
        }
    }

    private fun Int.toErrorKind(): PatchErrorKind = when (this) {
        NativeStatus.NOT_VCDIFF -> PatchErrorKind.NOT_A_PATCH
        NativeStatus.CORRUPT_PATCH -> PatchErrorKind.PATCH_CORRUPT
        NativeStatus.UNSUPPORTED -> PatchErrorKind.UNSUPPORTED_PATCH
        NativeStatus.SOURCE_READ_ERROR, NativeStatus.PATCH_READ_ERROR -> PatchErrorKind.READ_ERROR
        NativeStatus.OUTPUT_WRITE_ERROR -> PatchErrorKind.WRITE_ERROR
        NativeStatus.NO_SPACE -> PatchErrorKind.NO_SPACE
        NativeStatus.CHECKSUM_MISMATCH -> PatchErrorKind.SOURCE_MISMATCH
        NativeStatus.OUT_OF_MEMORY -> PatchErrorKind.OUT_OF_MEMORY
        NativeStatus.SOURCE_NOT_SEEKABLE -> PatchErrorKind.SOURCE_NOT_SEEKABLE
        NativeStatus.SOURCE_TOO_SMALL -> PatchErrorKind.SOURCE_TOO_SMALL
        else -> PatchErrorKind.UNEXPECTED
    }
}
