#!/usr/bin/env bash
# Host-side regression tests for the native XDelta engine.
# Requires: g++, python3 (3.9+ for randbytes).  Usage: ./run_tests.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
CLI=/tmp/jullpatch_cli
W=$(mktemp -d)
g++ -std=c++17 -O2 -Wall -Wextra -o "$CLI" "$HERE/cli.cpp" "$HERE"/../../app/src/main/cpp/vcdiff/*.cpp || exit 1
pass=0; fail=0
ok()  { echo "PASS  $1"; pass=$((pass+1)); }
bad() { echo "FAIL  $1"; fail=$((fail+1)); }

roundtrip() { # name, gen-args...
  local name=$1; shift
  python3 "$HERE/make_test_patch.py" "$W/$name" "$@" >/dev/null || { bad "$name (generator)"; return; }
  "$CLI" "$W/$name/source.bin" "$W/$name/patch.xdelta" "$W/$name/out.bin" >/dev/null
  if [ $? -eq 0 ] && cmp -s "$W/$name/out.bin" "$W/$name/expected.bin"; then ok "$name"; else bad "$name"; fi
}
expect_status() { # name, expected status, source, patch
  local out; out=$("$CLI" "$3" "$4" "$W/o.bin"); local st=$?
  if [ $st -eq "$2" ]; then ok "$1 -> status $2"; else bad "$1 (got $st: $out)"; fi
}

roundtrip plain
roundtrip lzma_alone --secondary alone
roundtrip lzma_xz --secondary xz
roundtrip no_adler --no-adler --no-appheader
roundtrip many_windows --window 50000 --target-size 2000000 --secondary xz --seed 7
roundtrip small_window --window 1000 --target-size 200000 --seed 3
roundtrip tiny_source --source-size 200 --target-size 50000 --seed 5
roundtrip seeds_a --seed 11 --secondary alone
roundtrip seeds_b --seed 12 --secondary xz

# ---- inspector: structure, exact output size, flags, min source -------------
inspect_check() { # name
  local d="$W/$1" out; out=$("$CLI" --inspect "$d/patch.xdelta")
  local good=1
  for kv in windows target maxwin minsrc flags sec; do
    local want got
    want=$(grep "^$kv=" "$d/info.txt" | cut -d= -f2)
    got=$(echo "$out" | tr ' ' '\n' | grep "^$kv=" | cut -d= -f2)
    [ "$want" = "$got" ] || { good=0; echo "   $kv: want=$want got=$got"; }
  done
  [ $good -eq 1 ] && ok "inspect $1" || bad "inspect $1 ($out)"
}
for n in plain lzma_alone lzma_xz no_adler many_windows small_window tiny_source seeds_a seeds_b; do inspect_check $n; done

# fake DJW patch: inspector must flag it as unsupported, engine must refuse it (status 4)
python3 "$HERE/make_test_patch.py" "$W/djw" --secondary djw --target-size 300000 --window 100000 >/dev/null
inspect_check djw
expect_status "DJW patch rejected by engine" 4 "$W/djw/source.bin" "$W/djw/patch.xdelta"

# inspector on bad inputs
head -c 5000 /dev/urandom > "$W/garbage.xdelta"
"$CLI" --inspect "$W/garbage.xdelta" >/dev/null 2>&1; [ $? -eq 2 ] && ok "inspect garbage -> NotVcdiff" || bad "inspect garbage"
printf '' > "$W/empty2.xdelta"; "$CLI" --inspect "$W/empty2.xdelta" >/dev/null 2>&1; [ $? -eq 2 ] && ok "inspect empty -> NotVcdiff" || bad "inspect empty"
head -c 100000 "$W/plain/patch.xdelta" > "$W/trunc2.xdelta"; "$CLI" --inspect "$W/trunc2.xdelta" >/dev/null 2>&1; [ $? -eq 3 ] && ok "inspect truncated -> CorruptPatch" || bad "inspect truncated"
# inspector must not move the shared file offset (uses pread) -- sanity via unchanged result on repeat
a=$("$CLI" --inspect "$W/plain/patch.xdelta"); b=$("$CLI" --inspect "$W/plain/patch.xdelta"); [ "$a" = "$b" ] && ok "inspect is repeatable" || bad "inspect repeat"

P="$W/plain"
# wrong source -> checksum mismatch (9)
head -c 3000000 /dev/urandom > "$W/wrong.bin"
expect_status "wrong source file" 9 "$W/wrong.bin" "$P/patch.xdelta"
# source too small (13)
head -c 1000 "$P/source.bin" > "$W/short.bin"
expect_status "source too small" 13 "$W/short.bin" "$P/patch.xdelta"
# truncated patch (3)
head -c 100000 "$P/patch.xdelta" > "$W/trunc.xdelta"
expect_status "truncated patch" 3 "$P/source.bin" "$W/trunc.xdelta"
# not vcdiff (2)
head -c 5000 /dev/urandom > "$W/garbage.xdelta"
expect_status "random file as patch" 2 "$P/source.bin" "$W/garbage.xdelta"
: > "$W/empty.xdelta"
expect_status "empty patch" 2 "$P/source.bin" "$W/empty.xdelta"
# corrupted patch: flip bytes at several places; must never crash or "succeed" silently
cnt=0; for off in 120 500 5000 50000 150000; do
  cp "$P/patch.xdelta" "$W/c.xdelta"; printf '\xAA' | dd of="$W/c.xdelta" bs=1 seek=$off conv=notrunc 2>/dev/null
  "$CLI" "$P/source.bin" "$W/c.xdelta" "$W/o.bin" >/dev/null; st=$?
  if [ $st -ne 0 ] && [ $st -lt 64 ]; then cnt=$((cnt+1)); fi
done
[ $cnt -eq 5 ] && ok "corrupted patch detected (5/5)" || bad "corrupted patch detected ($cnt/5)"
# lzma corruption
L="$W/lzma_xz"; cp "$L/patch.xdelta" "$W/c.xdelta"; printf '\x55\x55\x55' | dd of="$W/c.xdelta" bs=1 seek=3000 conv=notrunc 2>/dev/null
"$CLI" "$L/source.bin" "$W/c.xdelta" "$W/o.bin" >/dev/null; st=$?
[ $st -ne 0 ] && [ $st -lt 64 ] && ok "corrupted LZMA patch detected" || bad "corrupted LZMA patch ($st)"
# cancellation (1)
out=$("$CLI" "$P/source.bin" "$P/patch.xdelta" "$W/o.bin" 1500000); [ $? -eq 1 ] && ok "cancellation mid-run" || bad "cancellation ($out)"
# output to full device (ENOSPC -> 8)
if [ -w /dev/full ]; then
  out=$("$CLI" "$P/source.bin" "$P/patch.xdelta" /dev/full); st=$?
  [ $st -eq 8 ] && ok "no space on device -> status 8" || bad "ENOSPC ($st: $out)"
fi
# >4 GiB offsets with a sparse source (no real disk use)
python3 "$HERE/make_test_patch.py" "$W/huge" --sparse-source --source-size 6000000000 --target-size 3000000 --window 500000 --secondary xz >/dev/null
"$CLI" "$W/huge/source.bin" "$W/huge/patch.xdelta" "$W/huge/out.bin" >/dev/null
cmp -s "$W/huge/out.bin" "$W/huge/expected.bin" && ok "6 GB source, 64-bit offsets" || bad "6 GB source"
rm -rf "$W"
echo "---- $pass passed, $fail failed"
[ $fail -eq 0 ]
