// Host-side test driver for the native engine (not part of the Android build).
// usage: jullpatch_cli <source> <patch> <output> [cancel_after_bytes]
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cstdio>
#include <cstdlib>
#include <string>

#include "../../app/src/main/cpp/vcdiff/fd_io.h"
#include "../../app/src/main/cpp/vcdiff/vcdiff_decoder.h"
#include "../../app/src/main/cpp/vcdiff/vcdiff_inspector.h"

int main(int argc, char** argv) {
    using namespace jullpatch;
    if (argc == 3 && std::string(argv[1]) == "--inspect") {
        int fd = open(argv[2], O_RDONLY);
        struct stat st;
        if (fd < 0 || fstat(fd, &st) != 0) return 65;
        PatchInfo i = inspectPatchFd(fd, st.st_size);
        std::printf("status=%d windows=%llu target=%llu maxwin=%llu minsrc=%llu flags=%u sec=%u\n", (int)i.status,
                    (unsigned long long)i.windows, (unsigned long long)i.totalTargetBytes,
                    (unsigned long long)i.maxWindowBytes, (unsigned long long)i.minSourceBytes, i.flags,
                    (unsigned)i.secondaryId);
        return (int)i.status;
    }
    if (argc < 4) {
        std::fprintf(stderr, "usage: %s source patch output [cancel_after_output_bytes]\n", argv[0]);
        return 64;
    }
    const uint64_t cancelAfter = argc > 4 ? std::strtoull(argv[4], nullptr, 10) : 0;
    int s = open(argv[1], O_RDONLY), p = open(argv[2], O_RDONLY);
    int o = open(argv[3], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (s < 0 || p < 0 || o < 0) {
        std::perror("open");
        return 65;
    }
    struct stat ss, ps;
    fstat(s, &ss);
    fstat(p, &ps);
    FdIO io(s, p, o, ss.st_size, ps.st_size,
            [&](uint64_t, uint64_t out) { return !(cancelAfter && out >= cancelAfter); },
            /*minProgressIntervalNs=*/0);
    Result r = VcdiffDecoder(io).run();
    io.sync();
    std::printf("status=%d output=%llu msg=%s\n", (int)r.status, (unsigned long long)r.outputBytes,
                r.message.c_str());
    return (int)r.status;
}
