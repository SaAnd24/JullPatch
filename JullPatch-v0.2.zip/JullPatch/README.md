# JullPatch v0.2 — XDelta Patcher

Android app (Kotlin + Jetpack Compose + NDK/C++) that applies `.xdelta` (VCDIFF, RFC 3284) patches locally.

## Build
Open the folder in Android Studio (JDK 17). It downloads Gradle 8.9 and asks for NDK 26.1.10909125 and CMake 3.22.1.
`gradle-wrapper.jar` is not included (binary); run `gradle wrapper` once if you want `./gradlew`.
The GitHub Actions workflow in `.github/workflows/build.yml` builds a debug APK.

## What v0.2 adds
- Guided flow: original → patch → destination → validation → apply → result.
- Pre-flight validation from the real files: patch container parsed by the native inspector (exact output size,
  windows, features, minimum original size, checksums present), free space vs. required space, seekability.
- Hashes (CRC32, MD5, SHA-1, SHA-256): one streaming pass, on demand, cached per file version.
- Real progress from bytes written vs. exact output size; speed and ETA; non-blocking UI; foreground service.
- Cancellation: native engine stops at the next checkpoint; incomplete output is deleted.
- Crash/kill recovery: runs are recorded as RUNNING; on next start the incomplete output is deleted.
- Local history (SQLite).

## Layout
- `app/src/main/cpp/vcdiff/` portable engine: decoder, **inspector**, LZMA/LZMA2, fd IO (no Android deps)
- `app/src/main/cpp/jni/` JNI bridge (`nativeApply`, `nativeInspect`)
- `.../domain/` models, ports (`PatchEngine`, `PatchInspector`, `FileGateway`, `HistoryRepository`),
  use cases (`Validate`, `Apply`, `ComputeHashes`, `RecoverInterruptedJobs`), `hashing/`
- `.../data/` engine + inspector (JNI), SAF gateway, SQLite history
- `.../service/` `PatchJobManager`, `PatchForegroundService`
- `.../ui/` ViewModel + Compose screens
- `tools/native-test/` host tests for the engine: `bash tools/native-test/run_tests.sh`

New patch formats: implement `PatchEngine` + `PatchInspector` and register them in `AppContainer`.
