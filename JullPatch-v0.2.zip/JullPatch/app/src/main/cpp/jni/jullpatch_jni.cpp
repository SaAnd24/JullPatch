// JNI bridge: com.jullpatch.app.data.engine.NativeXdelta
#include <jni.h>

#include "../vcdiff/fd_io.h"
#include "../vcdiff/vcdiff_decoder.h"
#include "../vcdiff/vcdiff_inspector.h"

namespace {

struct ListenerRefs {
    JNIEnv* env;
    jobject listener;
    jmethodID onProgress;
    jmethodID onMessage;
    bool failed = false;
};

}  // namespace

extern "C" JNIEXPORT jint JNICALL
Java_com_jullpatch_app_data_engine_NativeXdelta_nativeApply(JNIEnv* env, jclass /*clazz*/,
                                                            jint sourceFd, jint patchFd,
                                                            jint outputFd, jlong sourceSize,
                                                            jlong patchSize, jobject listener) {
    using namespace jullpatch;

    jclass listenerClass = env->GetObjectClass(listener);
    ListenerRefs refs{env, listener, env->GetMethodID(listenerClass, "onProgress", "(JJ)Z"),
                      env->GetMethodID(listenerClass, "onMessage", "(Ljava/lang/String;)V")};
    if (refs.onProgress == nullptr || refs.onMessage == nullptr) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        return static_cast<jint>(Status::Internal);
    }

    FdIO io(sourceFd, patchFd, outputFd, sourceSize < 0 ? kUnknownSize : static_cast<uint64_t>(sourceSize),
            patchSize < 0 ? kUnknownSize : static_cast<uint64_t>(patchSize),
            [&refs](uint64_t patchBytes, uint64_t outputBytes) -> bool {
                jboolean keepGoing = refs.env->CallBooleanMethod(
                    refs.listener, refs.onProgress, static_cast<jlong>(patchBytes),
                    static_cast<jlong>(outputBytes));
                if (refs.env->ExceptionCheck()) {
                    refs.env->ExceptionClear();
                    refs.failed = true;
                    return false;
                }
                return keepGoing == JNI_TRUE;
            });

    VcdiffDecoder decoder(io);
    Result result = decoder.run();
    if (result.status == Status::Ok) io.sync();

    // Final, un-throttled progress report so the host knows the exact number of bytes written.
    if (result.status == Status::Ok) {
        refs.env->CallBooleanMethod(refs.listener, refs.onProgress,
                                    static_cast<jlong>(patchSize < 0 ? 0 : patchSize),
                                    static_cast<jlong>(result.outputBytes));
        if (refs.env->ExceptionCheck()) refs.env->ExceptionClear();
    }

    if (result.status != Status::Ok && !result.message.empty()) {
        jstring msg = env->NewStringUTF(result.message.c_str());
        if (msg != nullptr) {
            env->CallVoidMethod(listener, refs.onMessage, msg);
            env->DeleteLocalRef(msg);
        }
        if (env->ExceptionCheck()) env->ExceptionClear();
    }
    if (refs.failed && result.status == Status::Cancelled) return static_cast<jint>(Status::Cancelled);
    return static_cast<jint>(result.status);
}

// Returns long[7]: status, windows, totalTargetBytes, maxWindowBytes, minSourceBytes, flags, secondaryId.
extern "C" JNIEXPORT jlongArray JNICALL
Java_com_jullpatch_app_data_engine_NativeXdelta_nativeInspect(JNIEnv* env, jclass /*clazz*/,
                                                              jint patchFd, jlong patchSize) {
    using namespace jullpatch;
    PatchInfo info = inspectPatchFd(patchFd, patchSize < 0 ? kUnknownSize : static_cast<uint64_t>(patchSize));
    jlong values[7] = {static_cast<jlong>(info.status),
                       static_cast<jlong>(info.windows),
                       static_cast<jlong>(info.totalTargetBytes),
                       static_cast<jlong>(info.maxWindowBytes),
                       static_cast<jlong>(info.minSourceBytes),
                       static_cast<jlong>(info.flags),
                       static_cast<jlong>(info.secondaryId)};
    jlongArray result = env->NewLongArray(7);
    if (result == nullptr) return nullptr;
    env->SetLongArrayRegion(result, 0, 7, values);
    return result;
}
