#include "vcdiff_inspector.h"

#include <errno.h>
#include <unistd.h>

#include <algorithm>

#include "patch_io.h"

namespace jullpatch {
namespace {

constexpr uint64_t kMaxWindowBytes = 256ull * 1024 * 1024;  // same limit as the decoder

class PosReader {
public:
    PosReader(int fd, uint64_t size) : fd_(fd), size_(size) {}

    // 0..255, -1 on clean EOF, -2 on error (see errorStatus()).
    int get() {
        if (pos_ < bufStart_ || pos_ >= bufStart_ + bufLen_) {
            int r = load(pos_);
            if (r != 0) return r;
        }
        return buf_[pos_++ - bufStart_];
    }

    uint64_t pos() const { return pos_; }
    Status errorStatus() const { return error_; }

    // Advances over n bytes; verifies that they exist.
    bool skip(uint64_t n) {
        if (n == 0) return true;
        if (n > UINT64_MAX - pos_) return false;
        const uint64_t target = pos_ + n;
        if (size_ != kUnknownSize) {
            if (target > size_) return false;
        } else {
            uint8_t b;
            if (pread64(fd_, &b, 1, static_cast<off64_t>(target - 1)) != 1) return false;
        }
        pos_ = target;
        return true;
    }

    // Reads a base-128 varint. Returns 0 ok, -1 truncated/overflow, -2 IO error.
    int varint(uint64_t& v) {
        v = 0;
        for (int i = 0; i < 10; i++) {
            int b = get();
            if (b == -2) return -2;
            if (b < 0) return -1;
            if (v > (UINT64_MAX >> 7)) return -1;
            v = (v << 7) | static_cast<uint64_t>(b & 0x7F);
            if (!(b & 0x80)) return 0;
        }
        return -1;
    }

private:
    int load(uint64_t at) {
        ssize_t r;
        do {
            r = ::pread64(fd_, buf_, sizeof(buf_), static_cast<off64_t>(at));
        } while (r < 0 && errno == EINTR);
        if (r < 0) {
            error_ = errno == ESPIPE ? Status::SourceNotSeekable : Status::PatchReadError;
            return -2;
        }
        if (r == 0) return -1;
        bufStart_ = at;
        bufLen_ = static_cast<size_t>(r);
        return 0;
    }

    int fd_;
    uint64_t size_;
    uint64_t pos_ = 0;
    uint64_t bufStart_ = 0;
    size_t bufLen_ = 0;
    uint8_t buf_[4096];
    Status error_ = Status::Ok;
};

}  // namespace

PatchInfo inspectPatchFd(int fd, uint64_t patchSize) {
    PatchInfo info;
    PosReader r(fd, patchSize);

    auto fail = [&](Status s) {
        info.status = s;
        return info;
    };
    // Maps a reader result (-1 truncated, -2 IO error) to a Status.
    auto readFail = [&](int code) { return fail(code == -2 ? r.errorStatus() : Status::CorruptPatch); };

    uint8_t magic[4];
    for (int i = 0; i < 4; i++) {
        int b = r.get();
        if (b == -2) return fail(r.errorStatus());
        if (b < 0) return fail(Status::NotVcdiff);
        magic[i] = static_cast<uint8_t>(b);
    }
    if (magic[0] != 0xD6 || magic[1] != 0xC3 || magic[2] != 0xC4) return fail(Status::NotVcdiff);
    if (magic[3] != 0) return fail(Status::Unsupported);

    int hdr = r.get();
    if (hdr < 0) return readFail(hdr);
    if (hdr & ~0x07) return fail(Status::CorruptPatch);
    if (hdr & 0x01) {
        int id = r.get();
        if (id < 0) return readFail(id);
        info.secondaryId = static_cast<uint8_t>(id);
    }
    if (hdr & 0x02) {  // custom code table: cannot be walked, and the decoder rejects it
        info.flags |= kFlagCustomCodeTable;
        return info;
    }
    if (hdr & 0x04) {
        uint64_t appLen;
        int rc = r.varint(appLen);
        if (rc != 0) return readFail(rc);
        if (appLen > (1u << 20) || !r.skip(appLen)) return fail(Status::CorruptPatch);
    }

    bool allChecksums = true;
    for (;;) {
        int win = r.get();
        if (win == -1) break;  // clean end of patch
        if (win == -2) return fail(r.errorStatus());
        if ((win & ~0x07) || ((win & 1) && (win & 2))) return fail(Status::CorruptPatch);

        uint64_t srcLen = 0, srcPos = 0;
        int rc;
        if (win & 0x03) {
            if ((rc = r.varint(srcLen)) != 0 || (rc = r.varint(srcPos)) != 0) return readFail(rc);
            if (srcLen > UINT64_MAX - srcPos) return fail(Status::CorruptPatch);
            info.minSourceBytes = std::max(info.minSourceBytes, srcPos + srcLen);
        }
        if (win & 1) info.flags |= kFlagUsesSource;
        if (win & 2) info.flags |= kFlagTargetWindows;

        uint64_t deltaLen, targetLen, addLen, instLen, addrLen;
        if ((rc = r.varint(deltaLen)) != 0) return readFail(rc);
        const uint64_t deltaStart = r.pos();
        if ((rc = r.varint(targetLen)) != 0) return readFail(rc);
        int deltaInd = r.get();
        if (deltaInd < 0) return readFail(deltaInd);
        if ((rc = r.varint(addLen)) != 0 || (rc = r.varint(instLen)) != 0 || (rc = r.varint(addrLen)) != 0)
            return readFail(rc);
        if (deltaInd & ~0x07) return fail(Status::CorruptPatch);
        if (win & 0x04) {
            for (int i = 0; i < 4; i++) {
                int b = r.get();
                if (b < 0) return readFail(b);
            }
        } else {
            allChecksums = false;
        }

        const uint64_t headerBytes = r.pos() - deltaStart;
        if (addLen > UINT64_MAX / 4 || instLen > UINT64_MAX / 4 || addrLen > UINT64_MAX / 4 ||
            deltaLen < headerBytes || deltaLen - headerBytes != addLen + instLen + addrLen)
            return fail(Status::CorruptPatch);
        if (!r.skip(deltaLen - headerBytes)) return fail(Status::CorruptPatch);

        if (deltaInd != 0) {
            if (info.secondaryId == 2) info.flags |= kFlagUsesLzma;
            else info.flags |= kFlagUnsupportedSecondary;
        }
        if (targetLen > kMaxWindowBytes || addLen > kMaxWindowBytes || instLen > kMaxWindowBytes ||
            addrLen > kMaxWindowBytes)
            info.flags |= kFlagWindowTooLarge;

        if (targetLen > UINT64_MAX - info.totalTargetBytes) return fail(Status::CorruptPatch);
        info.totalTargetBytes += targetLen;
        info.maxWindowBytes = std::max(info.maxWindowBytes, targetLen);
        info.windows++;
    }
    if (allChecksums && info.windows > 0) info.flags |= kFlagAllChecksums;
    return info;
}

}  // namespace jullpatch
