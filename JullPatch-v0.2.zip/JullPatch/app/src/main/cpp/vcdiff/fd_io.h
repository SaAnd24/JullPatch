#pragma once
#include <functional>
#include <vector>

#include "patch_io.h"

namespace jullpatch {

// PatchIO over POSIX file descriptors (as handed out by Android's
// ContentResolver.openFileDescriptor). It never closes the descriptors.
class FdIO : public PatchIO {
public:
    using ProgressFn = std::function<bool(uint64_t patchBytes, uint64_t outputBytes)>;

    FdIO(int sourceFd, int patchFd, int outputFd, uint64_t sourceSize, uint64_t patchSize,
         ProgressFn progress, uint64_t minProgressIntervalNs = 100ull * 1000 * 1000);

    ssize_t readPatch(uint8_t* dst, size_t n) override;
    Status readSource(uint64_t offset, uint8_t* dst, size_t n) override;
    Status writeOutput(const uint8_t* src, size_t n) override;
    bool onProgress(uint64_t patchBytesRead, uint64_t outputBytes) override;
    uint64_t sourceSize() const override { return sourceSize_; }
    uint64_t patchSize() const override { return patchSize_; }

    // Flushes the output to stable storage (best effort).
    void sync();

private:
    struct Block {
        uint64_t offset = 0;
        size_t length = 0;
        uint64_t lastUse = 0;
        std::vector<uint8_t> data;
    };
    static constexpr size_t kBlockSize = 1u << 20;
    static constexpr int kBlocks = 4;

    Status preadFully(uint64_t offset, uint8_t* dst, size_t n);

    int sourceFd_, patchFd_, outputFd_;
    uint64_t sourceSize_, patchSize_;
    ProgressFn progress_;
    Block blocks_[kBlocks];
    uint64_t useCounter_ = 0;
    uint64_t lastProgressNs_ = 0;
    uint64_t minIntervalNs_;
};

}  // namespace jullpatch
