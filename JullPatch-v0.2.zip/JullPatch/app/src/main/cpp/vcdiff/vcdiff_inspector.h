#pragma once
#include <cstdint>

#include "status.h"

namespace jullpatch {

// Bit flags describing a patch (kept in sync with Kotlin: NativeXdelta.InspectFlags).
constexpr uint32_t kFlagAllChecksums = 1;         // every window carries an Adler-32
constexpr uint32_t kFlagUsesSource = 2;           // at least one window copies from the source file
constexpr uint32_t kFlagUsesLzma = 4;             // sections compressed with LZMA
constexpr uint32_t kFlagUnsupportedSecondary = 8; // sections use DJW/FGK/unknown secondary compression
constexpr uint32_t kFlagTargetWindows = 16;       // VCD_TARGET windows (unsupported)
constexpr uint32_t kFlagCustomCodeTable = 32;     // custom code table (unsupported)
constexpr uint32_t kFlagWindowTooLarge = 64;      // a window exceeds the decoder limit

struct PatchInfo {
    Status status = Status::Ok;
    uint64_t windows = 0;
    uint64_t totalTargetBytes = 0;  // exact size of the patched output
    uint64_t maxWindowBytes = 0;
    uint64_t minSourceBytes = 0;    // source must be at least this large
    uint32_t flags = 0;
    uint8_t secondaryId = 0;
};

// Walks the window headers of a patch with positional reads (no decoding, no
// whole-file read, does not move the file offset). Applies the same structural
// checks as the decoder, so a successful inspection means the container is
// well-formed; it cannot prove the instruction streams or LZMA data are intact.
// Returns Status::SourceNotSeekable when the descriptor does not support pread.
PatchInfo inspectPatchFd(int fd, uint64_t patchSize);

}  // namespace jullpatch
