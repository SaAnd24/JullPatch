package com.jullpatch.app.domain.engine

import com.jullpatch.app.domain.files.OpenedFile
import com.jullpatch.app.domain.model.InspectionResult

/** Reads facts about a patch (size of the result, features used) without applying it. */
interface PatchInspector {
    fun inspect(patch: OpenedFile): InspectionResult
}
