package com.jullpatch.app.domain.hashing

/** Identifies a file version. A different size or modification time means a different key. */
data class FileFingerprint(
    val uri: String,
    val sizeBytes: Long,
    val lastModified: Long?,
)

/** Avoids hashing the same unchanged file twice. Swap the implementation to persist it later. */
interface HashCache {
    fun get(key: FileFingerprint): Map<HashAlgorithm, String>
    fun put(key: FileFingerprint, values: Map<HashAlgorithm, String>)
}

class InMemoryHashCache(private val maxEntries: Int = 32) : HashCache {
    private val map = object : LinkedHashMap<FileFingerprint, Map<HashAlgorithm, String>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<FileFingerprint, Map<HashAlgorithm, String>>?): Boolean {
            return size > maxEntries
        }
    }

    @Synchronized
    override fun get(key: FileFingerprint): Map<HashAlgorithm, String> = map[key].orEmpty()

    @Synchronized
    override fun put(key: FileFingerprint, values: Map<HashAlgorithm, String>) {
        map[key] = (map[key].orEmpty()) + values
    }
}
