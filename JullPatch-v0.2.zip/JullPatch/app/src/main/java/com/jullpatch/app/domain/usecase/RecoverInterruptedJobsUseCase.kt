package com.jullpatch.app.domain.usecase

import android.net.Uri
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.history.HistoryCompletion
import com.jullpatch.app.domain.history.HistoryRepository
import com.jullpatch.app.domain.history.HistoryResult

/**
 * Runs at startup. A history entry still marked RUNNING means the previous process died while
 * patching (killed, crashed, swiped away): its output is incomplete, so it is deleted and the entry
 * is closed as INTERRUPTED.
 */
class RecoverInterruptedJobsUseCase(
    private val history: HistoryRepository,
    private val files: FileGateway,
) {
    suspend fun execute() {
        for (entry in history.running()) {
            val uri = Uri.parse(entry.outputUri)
            files.delete(uri)
            files.releaseAccess(uri)
            history.finish(
                entry.id,
                HistoryCompletion(
                    result = HistoryResult.INTERRUPTED,
                    finishedAt = System.currentTimeMillis(),
                ),
            )
        }
    }
}
