package com.jullpatch.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.jullpatch.app.R
import com.jullpatch.app.domain.model.IssueCode
import com.jullpatch.app.domain.model.UnsupportedFeature
import com.jullpatch.app.domain.model.ValidationIssue

@Composable
internal fun ValidationIssue.messageText(): String = when (code) {
    IssueCode.SOURCE_TOO_SMALL -> stringResource(
        R.string.issue_source_too_small,
        formatBytes(args.getOrNull(0)?.toLongOrNull() ?: 0L),
        formatBytes(args.getOrNull(1)?.toLongOrNull() ?: 0L),
    )
    IssueCode.NO_SPACE -> stringResource(
        R.string.issue_no_space,
        formatBytes(args.getOrNull(0)?.toLongOrNull() ?: 0L),
        formatBytes(args.getOrNull(1)?.toLongOrNull() ?: 0L),
    )
    IssueCode.PATCH_UNSUPPORTED_FEATURE -> stringResource(R.string.issue_unsupported_feature, featureName(args.getOrNull(0)))
    IssueCode.PATCH_NO_CHECKSUM -> stringResource(R.string.warn_no_checksum)
    IssueCode.PATCH_NOT_INSPECTABLE -> stringResource(R.string.warn_not_inspectable)
    IssueCode.SPACE_UNKNOWN -> stringResource(R.string.warn_space_unknown)
    else -> stringResource((code.errorKind ?: com.jullpatch.app.domain.model.PatchErrorKind.UNEXPECTED).messageRes())
}

@Composable
private fun featureName(name: String?): String {
    val feature = name?.let { runCatching { UnsupportedFeature.valueOf(it) }.getOrNull() }
    return when (feature) {
        UnsupportedFeature.SECONDARY_COMPRESSION -> stringResource(R.string.feature_secondary)
        UnsupportedFeature.TARGET_WINDOWS -> stringResource(R.string.feature_target_windows)
        UnsupportedFeature.CUSTOM_CODE_TABLE -> stringResource(R.string.feature_code_table)
        UnsupportedFeature.WINDOW_TOO_LARGE -> stringResource(R.string.feature_window_large)
        null -> name.orEmpty()
    }
}
