package com.jullpatch.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jullpatch.app.ui.MainActions
import com.jullpatch.app.ui.MainScreen
import com.jullpatch.app.ui.MainViewModel
import com.jullpatch.app.ui.theme.JullPatchTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        MainViewModel.factory((application as JullPatchApp).container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JullPatchTheme {
                MainRoute(viewModel)
            }
        }
    }
}

@Composable
private fun MainRoute(viewModel: MainViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Storage Access Framework pickers: no storage permissions, no absolute paths.
    val pickSource = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.onSourcePicked(uri)
    }
    val pickPatch = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.onPatchPicked(uri)
    }
    // "*/*" avoids Android appending an extension (e.g. ".bin") to the suggested file name.
    val pickOutput = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("*/*"),
    ) { uri ->
        if (uri != null) viewModel.onOutputPicked(uri)
    }

    // Notification permission only improves the foreground notification; patching works without it.
    var askedForNotifications by rememberSaveable { mutableStateOf(false) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        viewModel.startPatch()
    }

    val actions = MainActions(
        onOpenForm = viewModel::openForm,
        onBackToHome = viewModel::backToHome,
        onOpenHistory = viewModel::openHistory,
        onCloseHistory = viewModel::closeHistory,
        onClearHistory = viewModel::clearHistory,
        onPickSource = { pickSource.launch(arrayOf("*/*")) },
        onPickPatch = { pickPatch.launch(arrayOf("*/*")) },
        onPickOutput = { pickOutput.launch(state.suggestedOutputName) },
        onComputeHashes = viewModel::computeHashes,
        onCancelHashes = viewModel::cancelHashes,
        onApply = {
            val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                !askedForNotifications &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            if (needsPermission) {
                askedForNotifications = true
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                viewModel.startPatch()
            }
        },
        onCancel = viewModel::cancelPatch,
        onDismissResult = viewModel::dismissResult,
    )
    MainScreen(state = state, actions = actions)
}
