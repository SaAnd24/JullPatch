package com.jullpatch.app.domain.model

enum class UnsupportedFeature {
    SECONDARY_COMPRESSION,
    TARGET_WINDOWS,
    CUSTOM_CODE_TABLE,
    WINDOW_TOO_LARGE,
}

/** Facts read from the patch container itself (not inferred from the file extension). */
data class PatchInfo(
    val windowCount: Long,
    /** Exact size of the patched output. */
    val totalOutputBytes: Long,
    val maxWindowBytes: Long,
    /** The original file must be at least this large. */
    val minSourceBytes: Long,
    /** Every window carries a checksum, so a wrong original file is detected. */
    val hasChecksums: Boolean,
    val usesSourceFile: Boolean,
    val usesLzma: Boolean,
    val unsupported: Set<UnsupportedFeature>,
)

sealed interface InspectionResult {
    data class Info(val info: PatchInfo) : InspectionResult

    /** The file is not a usable patch. */
    data class Invalid(val kind: PatchErrorKind, val detail: String? = null) : InspectionResult

    /** The patch could not be inspected ahead of time (e.g. it is not seekable); applying may still work. */
    data object Unavailable : InspectionResult
}
