package com.jullpatch.app.domain.history

import com.jullpatch.app.domain.model.PatchErrorKind
import kotlinx.coroutines.flow.Flow

enum class HistoryResult { RUNNING, SUCCESS, FAILED, CANCELLED, INTERRUPTED }

data class HistoryEntry(
    val id: Long,
    val startedAt: Long,
    val finishedAt: Long?,
    val sourceName: String,
    val sourceUri: String,
    val patchName: String,
    val patchUri: String,
    val outputName: String,
    val outputUri: String,
    val outputSize: Long?,
    val result: HistoryResult,
    val errorKind: PatchErrorKind?,
    val errorDetail: String?,
    val durationMs: Long?,
)

data class NewHistoryEntry(
    val startedAt: Long,
    val sourceName: String,
    val sourceUri: String,
    val patchName: String,
    val patchUri: String,
    val outputName: String,
    val outputUri: String,
)

data class HistoryCompletion(
    val result: HistoryResult,
    val finishedAt: Long,
    val outputSize: Long? = null,
    val errorKind: PatchErrorKind? = null,
    val errorDetail: String? = null,
    val durationMs: Long? = null,
)

/** Local patch history. Storage is an implementation detail so it can grow into a Library later. */
interface HistoryRepository {
    /** Newest first. Emits again after every change. */
    val entries: Flow<List<HistoryEntry>>

    suspend fun start(entry: NewHistoryEntry): Long
    suspend fun finish(id: Long, completion: HistoryCompletion)

    /** Entries still marked RUNNING (a previous process died while patching). */
    suspend fun running(): List<HistoryEntry>
    suspend fun delete(id: Long)
    suspend fun clear()
}
