package com.jullpatch.app.domain.hashing

import java.security.MessageDigest
import java.util.zip.CRC32

/** Incremental digest. Implement it to add a new algorithm. */
interface HashDigest {
    fun update(buffer: ByteArray, offset: Int, length: Int)

    /** Lower-case hexadecimal digest; call once, after the last update. */
    fun digestHex(): String
}

/**
 * Supported hash algorithms. To add one (e.g. SHA-512 or xxHash), add an entry here;
 * hashing, caching and the UI work from this list.
 */
enum class HashAlgorithm(val label: String, private val factory: () -> HashDigest) {
    CRC32("CRC32", { Crc32Digest() }),
    MD5("MD5", { MessageDigestAdapter("MD5") }),
    SHA1("SHA-1", { MessageDigestAdapter("SHA-1") }),
    SHA256("SHA-256", { MessageDigestAdapter("SHA-256") });

    fun newDigest(): HashDigest = factory()
}

private class Crc32Digest : HashDigest {
    private val crc = CRC32()

    override fun update(buffer: ByteArray, offset: Int, length: Int) {
        crc.update(buffer, offset, length)
    }

    override fun digestHex(): String = String.format("%08x", crc.value)
}

private class MessageDigestAdapter(algorithm: String) : HashDigest {
    private val digest: MessageDigest = MessageDigest.getInstance(algorithm)

    override fun update(buffer: ByteArray, offset: Int, length: Int) {
        digest.update(buffer, offset, length)
    }

    override fun digestHex(): String {
        val bytes = digest.digest()
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            sb.append(HEX[(b.toInt() shr 4) and 0x0F])
            sb.append(HEX[b.toInt() and 0x0F])
        }
        return sb.toString()
    }

    private companion object {
        const val HEX = "0123456789abcdef"
    }
}
