package com.jullpatch.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.jullpatch.app.service.JobState

/** Callbacks the screens need; the Activity wires file pickers and the ViewModel behind them. */
class MainActions(
    val onOpenForm: () -> Unit,
    val onBackToHome: () -> Unit,
    val onOpenHistory: () -> Unit,
    val onCloseHistory: () -> Unit,
    val onClearHistory: () -> Unit,
    val onPickSource: () -> Unit,
    val onPickPatch: () -> Unit,
    val onPickOutput: () -> Unit,
    val onComputeHashes: (HashTarget) -> Unit,
    val onCancelHashes: (HashTarget) -> Unit,
    val onApply: () -> Unit,
    val onCancel: () -> Unit,
    val onDismissResult: () -> Unit,
)

@Composable
fun MainScreen(state: MainUiState, actions: MainActions) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when (val job = state.job) {
                is JobState.Running -> ProgressScreen(job, actions)
                is JobState.Finished -> ResultScreen(job, state, actions)
                JobState.Idle -> when (state.screen) {
                    Screen.HOME -> HomeScreen(actions)
                    Screen.FORM -> FormScreen(state, actions)
                    Screen.HISTORY -> HistoryScreen(state, actions)
                }
            }
        }
    }
}
