package com.jullpatch.app.domain.usecase

import com.jullpatch.app.domain.files.FileAccessException
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.files.FileRole
import com.jullpatch.app.domain.hashing.FileFingerprint
import com.jullpatch.app.domain.hashing.HashAlgorithm
import com.jullpatch.app.domain.hashing.HashCache
import com.jullpatch.app.domain.hashing.HashResult
import com.jullpatch.app.domain.hashing.StreamHasher
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.PatchErrorKind
import java.io.IOException

sealed interface HashOutcome {
    data class Done(val values: Map<HashAlgorithm, String>, val fromCache: Boolean) : HashOutcome
    data object Cancelled : HashOutcome
    data class Failed(val kind: PatchErrorKind) : HashOutcome
}

/**
 * Hashes a file in one streaming pass, reusing cached values and computing only the algorithms
 * that are missing.
 *
 * Blocking: call from a background dispatcher.
 */
class ComputeHashesUseCase(
    private val files: FileGateway,
    private val hasher: StreamHasher,
    private val cache: HashCache,
) {

    fun execute(
        file: FileRef,
        role: FileRole,
        algorithms: Set<HashAlgorithm> = HashAlgorithm.entries.toSet(),
        isCancelled: () -> Boolean = { false },
        onProgress: (processed: Long, total: Long?) -> Unit = { _, _ -> },
    ): HashOutcome {
        val size = file.sizeBytes
        val key = if (size != null) FileFingerprint(file.uri.toString(), size, file.lastModified) else null
        val cached = key?.let { cache.get(it) }.orEmpty()
        val missing = algorithms - cached.keys
        if (missing.isEmpty()) {
            return HashOutcome.Done(cached.filterKeys { it in algorithms }, fromCache = true)
        }

        var lastReport = 0L
        return try {
            files.openInputStream(file.uri, role).use { stream ->
                val result = hasher.hash(stream, missing, isCancelled) { processed ->
                    val now = System.nanoTime()
                    if (now - lastReport >= 100_000_000L) {
                        lastReport = now
                        onProgress(processed, size)
                    }
                }
                when (result) {
                    HashResult.Cancelled -> HashOutcome.Cancelled
                    is HashResult.Done -> {
                        val merged = cached + result.values
                        if (key != null) cache.put(key, merged)
                        HashOutcome.Done(merged.filterKeys { it in algorithms }, fromCache = false)
                    }
                }
            }
        } catch (e: FileAccessException) {
            HashOutcome.Failed(e.kind)
        } catch (e: IOException) {
            HashOutcome.Failed(PatchErrorKind.READ_ERROR)
        }
    }
}
