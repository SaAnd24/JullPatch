package com.jullpatch.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.jullpatch.app.R

/** Flow: original → patch → destination → validation → apply. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun FormScreen(state: MainUiState, actions: MainActions) {
    BackHandler(onBack = actions.onBackToHome)
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(stringResource(R.string.form_title)) },
            windowInsets = WindowInsets(0, 0, 0, 0),
            navigationIcon = {
                IconButton(onClick = actions.onBackToHome) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back_description))
                }
            },
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            StepCard(
                number = 1,
                title = stringResource(R.string.step_source),
                hint = stringResource(R.string.slot_source_hint),
                file = state.source,
                onClick = actions.onPickSource,
            ) {
                if (state.source != null) {
                    HashSection(
                        state = state.hashes[HashTarget.SOURCE],
                        onCompute = { actions.onComputeHashes(HashTarget.SOURCE) },
                        onCancel = { actions.onCancelHashes(HashTarget.SOURCE) },
                    )
                }
            }
            StepCard(
                number = 2,
                title = stringResource(R.string.step_patch),
                hint = stringResource(R.string.slot_patch_hint),
                file = state.patch,
                onClick = actions.onPickPatch,
            ) {
                if (state.patch != null) {
                    HashSection(
                        state = state.hashes[HashTarget.PATCH],
                        onCompute = { actions.onComputeHashes(HashTarget.PATCH) },
                        onCancel = { actions.onCancelHashes(HashTarget.PATCH) },
                    )
                }
            }
            StepCard(
                number = 3,
                title = stringResource(R.string.step_destination),
                hint = stringResource(R.string.slot_output_hint),
                file = state.output,
                onClick = actions.onPickOutput,
                showSize = false,
            )
            ValidationCard(state.validation)
            state.messageRes?.let {
                Text(
                    text = stringResource(it),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
        Button(
            onClick = actions.onApply,
            enabled = state.canApply,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .height(56.dp),
        ) {
            Text(stringResource(R.string.action_apply), style = MaterialTheme.typography.titleMedium)
        }
    }
}
