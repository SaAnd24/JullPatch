package com.jullpatch.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jullpatch.app.R
import com.jullpatch.app.domain.model.PatchStage
import com.jullpatch.app.service.JobState

@Composable
internal fun ProgressScreen(job: JobState.Running, actions: MainActions) {
    val progress = job.progress
    val fraction = progress.fraction
    val patching = progress.stage == PatchStage.PATCHING || progress.stage == PatchStage.CANCELLING
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            stringResource(R.string.progress_title),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            when (progress.stage) {
                PatchStage.VALIDATING -> stringResource(R.string.stage_validating)
                PatchStage.OPENING -> stringResource(R.string.stage_opening)
                PatchStage.PATCHING -> stringResource(R.string.stage_patching)
                PatchStage.CANCELLING -> stringResource(R.string.stage_cancelling)
            },
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.progress_input, progress.fileName), style = MaterialTheme.typography.bodyMedium)
        if (progress.outputName.isNotEmpty()) {
            Text(stringResource(R.string.progress_output, progress.outputName), style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.height(24.dp))

        if (fraction != null && patching) {
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text(formatPercent(fraction), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        } else {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(8.dp))

        val expected = progress.expectedOutputBytes
        if (expected != null && expected > 0L) {
            Text(
                stringResource(R.string.progress_processed, formatBytes(progress.outputBytes), formatBytes(expected)),
                style = MaterialTheme.typography.bodyMedium,
            )
        } else {
            Text(
                stringResource(R.string.progress_written, formatBytes(progress.outputBytes)),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        progress.bytesPerSecond?.let {
            Text(
                stringResource(R.string.progress_speed, formatRate(it)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        progress.etaSeconds?.let {
            Text(
                stringResource(R.string.progress_eta, formatEta(it)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(32.dp))
        OutlinedButton(
            onClick = actions.onCancel,
            enabled = !job.cancelling,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(stringResource(if (job.cancelling) R.string.action_cancelling else R.string.action_cancel))
        }
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.progress_cancel_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
        )
    }
}
