package com.jullpatch.app.ui

import androidx.annotation.StringRes
import com.jullpatch.app.R
import com.jullpatch.app.domain.model.PatchErrorKind

@StringRes
fun PatchErrorKind.messageRes(): Int = when (this) {
    PatchErrorKind.SOURCE_NOT_FOUND -> R.string.error_source_not_found
    PatchErrorKind.SOURCE_UNREADABLE -> R.string.error_source_unreadable
    PatchErrorKind.PATCH_NOT_FOUND -> R.string.error_patch_not_found
    PatchErrorKind.PATCH_UNREADABLE -> R.string.error_patch_unreadable
    PatchErrorKind.OUTPUT_UNWRITABLE -> R.string.error_output_unwritable
    PatchErrorKind.OUTPUT_SAME_AS_INPUT -> R.string.error_output_same_as_input
    PatchErrorKind.NOT_A_PATCH -> R.string.error_not_a_patch
    PatchErrorKind.PATCH_CORRUPT -> R.string.error_patch_corrupt
    PatchErrorKind.UNSUPPORTED_PATCH -> R.string.error_unsupported_patch
    PatchErrorKind.SOURCE_MISMATCH -> R.string.error_source_mismatch
    PatchErrorKind.SOURCE_TOO_SMALL -> R.string.error_source_too_small
    PatchErrorKind.SOURCE_NOT_SEEKABLE -> R.string.error_source_not_seekable
    PatchErrorKind.READ_ERROR -> R.string.error_read_error
    PatchErrorKind.WRITE_ERROR -> R.string.error_write_error
    PatchErrorKind.NO_SPACE -> R.string.error_no_space
    PatchErrorKind.OUT_OF_MEMORY -> R.string.error_out_of_memory
    PatchErrorKind.OUTPUT_INCOMPLETE -> R.string.error_output_incomplete
    PatchErrorKind.UNEXPECTED -> R.string.error_unexpected
}
