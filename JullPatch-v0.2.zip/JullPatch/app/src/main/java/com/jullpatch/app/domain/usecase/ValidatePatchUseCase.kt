package com.jullpatch.app.domain.usecase

import com.jullpatch.app.domain.engine.PatchInspector
import com.jullpatch.app.domain.files.FileAccessException
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.files.FileRole
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.InspectionResult
import com.jullpatch.app.domain.model.IssueCode
import com.jullpatch.app.domain.model.IssueSeverity
import com.jullpatch.app.domain.model.PatchErrorKind
import com.jullpatch.app.domain.model.PatchInfo
import com.jullpatch.app.domain.model.SpaceCheck
import com.jullpatch.app.domain.model.ValidationIssue
import com.jullpatch.app.domain.model.ValidationReport

/**
 * Pre-flight checks. Everything is verified against the real files: the patch container is parsed
 * (not trusted by extension), the exact output size is read from it, and free space is asked from
 * the destination volume. Works with partial input so the UI can validate step by step.
 *
 * Blocking: call from a background dispatcher.
 */
class ValidatePatchUseCase(
    private val files: FileGateway,
    private val inspector: PatchInspector,
) {

    fun execute(
        source: FileRef?,
        patch: FileRef?,
        output: FileRef?,
        isCancelled: () -> Boolean = { false },
    ): ValidationReport {
        val issues = mutableListOf<ValidationIssue>()
        var sourceSize: Long? = null
        var sourceSeekable = true
        var patchInfo: PatchInfo? = null

        // Must come before anything is opened for writing: never truncate an input file.
        val outputIsInput = output != null && (output.uri == source?.uri || output.uri == patch?.uri)
        if (outputIsInput) issues += blocker(IssueCode.OUTPUT_SAME_AS_INPUT)

        if (source != null) {
            try {
                files.openForRead(source.uri, FileRole.SOURCE).use { file ->
                    sourceSize = file.sizeBytes ?: source.sizeBytes
                    sourceSeekable = file.isSeekable
                }
            } catch (e: FileAccessException) {
                issues += blocker(sourceCode(e.kind))
            }
        }
        if (isCancelled()) return report(source, patch, output, sourceSize, patchInfo, null, issues)

        if (patch != null) {
            try {
                files.openForRead(patch.uri, FileRole.PATCH).use { file ->
                    val size = file.sizeBytes ?: patch.sizeBytes
                    if (size == 0L) {
                        issues += blocker(IssueCode.PATCH_EMPTY)
                    } else {
                        when (val result = inspector.inspect(file)) {
                            is InspectionResult.Info -> patchInfo = result.info
                            is InspectionResult.Invalid -> issues += blocker(invalidCode(result.kind))
                            InspectionResult.Unavailable -> issues += warning(IssueCode.PATCH_NOT_INSPECTABLE)
                        }
                    }
                    Unit
                }
            } catch (e: FileAccessException) {
                issues += blocker(patchCode(e.kind))
            }
        }
        if (isCancelled()) return report(source, patch, output, sourceSize, patchInfo, null, issues)

        val info = patchInfo
        if (info != null) {
            for (feature in info.unsupported) {
                issues += blocker(IssueCode.PATCH_UNSUPPORTED_FEATURE, feature.name)
            }
            val size = sourceSize
            if (size != null && info.minSourceBytes > size) {
                issues += blocker(IssueCode.SOURCE_TOO_SMALL, info.minSourceBytes.toString(), size.toString())
            }
            if (info.usesSourceFile && !sourceSeekable) issues += blocker(IssueCode.SOURCE_NOT_SEEKABLE)
            if (!info.hasChecksums) issues += warning(IssueCode.PATCH_NO_CHECKSUM)
        }

        var space: SpaceCheck? = null
        if (output != null && !outputIsInput) {
            try {
                files.openForWrite(output.uri).use { file ->
                    val available = file.availableSpaceBytes()
                    val required = info?.totalOutputBytes
                    space = SpaceCheck(requiredBytes = required, availableBytes = available)
                    if (available == null || required == null) {
                        issues += warning(IssueCode.SPACE_UNKNOWN)
                    } else if (required > available) {
                        issues += blocker(IssueCode.NO_SPACE, required.toString(), available.toString())
                    }
                    Unit
                }
            } catch (e: FileAccessException) {
                issues += blocker(IssueCode.OUTPUT_UNWRITABLE)
            }
        }

        return report(source, patch, output, sourceSize, patchInfo, space, issues)
    }

    private fun report(
        source: FileRef?,
        patch: FileRef?,
        output: FileRef?,
        sourceSize: Long?,
        patchInfo: PatchInfo?,
        space: SpaceCheck?,
        issues: List<ValidationIssue>,
    ) = ValidationReport(source, patch, output, sourceSize, patchInfo, space, issues.toList())

    private fun blocker(code: IssueCode, vararg args: String) =
        ValidationIssue(IssueSeverity.ERROR, code, args.toList())

    private fun warning(code: IssueCode, vararg args: String) =
        ValidationIssue(IssueSeverity.WARNING, code, args.toList())

    private fun sourceCode(kind: PatchErrorKind) =
        if (kind == PatchErrorKind.SOURCE_NOT_FOUND) IssueCode.SOURCE_NOT_FOUND else IssueCode.SOURCE_UNREADABLE

    private fun patchCode(kind: PatchErrorKind) =
        if (kind == PatchErrorKind.PATCH_NOT_FOUND) IssueCode.PATCH_NOT_FOUND else IssueCode.PATCH_UNREADABLE

    private fun invalidCode(kind: PatchErrorKind) = when (kind) {
        PatchErrorKind.NOT_A_PATCH -> IssueCode.PATCH_NOT_VCDIFF
        PatchErrorKind.PATCH_CORRUPT -> IssueCode.PATCH_CORRUPT
        PatchErrorKind.UNSUPPORTED_PATCH -> IssueCode.PATCH_UNSUPPORTED_FEATURE
        else -> IssueCode.PATCH_UNREADABLE
    }
}
