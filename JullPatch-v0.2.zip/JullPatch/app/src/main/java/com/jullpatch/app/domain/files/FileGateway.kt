package com.jullpatch.app.domain.files

import android.net.Uri
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.PatchErrorKind
import java.io.Closeable
import java.io.InputStream

enum class FileRole { SOURCE, PATCH, OUTPUT }

/** An open file exposed as a raw descriptor so the native engine can stream it. */
interface OpenedFile : Closeable {
    val fd: Int

    /** Size reported by fstat, or null when it cannot be determined. */
    val sizeBytes: Long?

    /** True when positional reads work (regular file). Pipes and some cloud providers are not seekable. */
    val isSeekable: Boolean

    /** Free bytes on the volume holding this file, or null when the platform cannot tell. */
    fun availableSpaceBytes(): Long?
}

class FileAccessException(
    val kind: PatchErrorKind,
    cause: Throwable? = null,
) : Exception(cause?.message ?: kind.name, cause)

/** Abstraction over file access so the patch logic never depends on Android storage APIs. */
interface FileGateway {
    fun describe(uri: Uri, role: FileRole): FileRef
    fun openForRead(uri: Uri, role: FileRole): OpenedFile
    fun openForWrite(uri: Uri): OpenedFile

    /** Plain stream for sequential reads (hashing). Closing it is the caller's job. */
    fun openInputStream(uri: Uri, role: FileRole): InputStream

    fun querySize(uri: Uri): Long?
    fun delete(uri: Uri): Boolean

    /**
     * Keeps write access to [uri] across process death so an interrupted run can be cleaned up
     * later. Best effort: silently ignored when the provider does not allow it.
     */
    fun retainAccess(uri: Uri)
    fun releaseAccess(uri: Uri)
}
