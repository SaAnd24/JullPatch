package com.jullpatch.app

import android.app.Application
import com.jullpatch.app.service.PatchNotifications
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JullPatchApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        PatchNotifications.createChannels(this)

        // A previous process may have died mid-patch: remove its incomplete output.
        container.appScope.launch(Dispatchers.IO) {
            runCatching { container.recoverInterruptedJobs.execute() }
        }
    }
}
