package com.jullpatch.app.domain.model

enum class IssueSeverity { ERROR, WARNING }

/** [errorKind] is the matching [PatchErrorKind] for blocking issues, null for warnings. */
enum class IssueCode(val errorKind: PatchErrorKind?) {
    SOURCE_NOT_FOUND(PatchErrorKind.SOURCE_NOT_FOUND),
    SOURCE_UNREADABLE(PatchErrorKind.SOURCE_UNREADABLE),
    SOURCE_TOO_SMALL(PatchErrorKind.SOURCE_TOO_SMALL),
    SOURCE_NOT_SEEKABLE(PatchErrorKind.SOURCE_NOT_SEEKABLE),
    PATCH_NOT_FOUND(PatchErrorKind.PATCH_NOT_FOUND),
    PATCH_UNREADABLE(PatchErrorKind.PATCH_UNREADABLE),
    PATCH_EMPTY(PatchErrorKind.NOT_A_PATCH),
    PATCH_NOT_VCDIFF(PatchErrorKind.NOT_A_PATCH),
    PATCH_CORRUPT(PatchErrorKind.PATCH_CORRUPT),
    PATCH_UNSUPPORTED_FEATURE(PatchErrorKind.UNSUPPORTED_PATCH),
    OUTPUT_UNWRITABLE(PatchErrorKind.OUTPUT_UNWRITABLE),
    OUTPUT_SAME_AS_INPUT(PatchErrorKind.OUTPUT_SAME_AS_INPUT),
    NO_SPACE(PatchErrorKind.NO_SPACE),
    PATCH_NO_CHECKSUM(null),
    PATCH_NOT_INSPECTABLE(null),
    SPACE_UNKNOWN(null),
}

data class ValidationIssue(
    val severity: IssueSeverity,
    val code: IssueCode,
    /** Numeric/text arguments for the message (sizes in bytes, feature names...). */
    val args: List<String> = emptyList(),
)

data class SpaceCheck(
    /** Exact bytes the output will need, or null when the patch could not be inspected. */
    val requiredBytes: Long?,
    /** Free bytes on the destination volume, or null when the platform does not report it. */
    val availableBytes: Long?,
)

data class ValidationReport(
    val source: FileRef?,
    val patch: FileRef?,
    val output: FileRef?,
    val sourceSizeBytes: Long?,
    val patchInfo: PatchInfo?,
    val space: SpaceCheck?,
    val issues: List<ValidationIssue>,
) {
    val hasErrors: Boolean get() = issues.any { it.severity == IssueSeverity.ERROR }
    val firstError: ValidationIssue? get() = issues.firstOrNull { it.severity == IssueSeverity.ERROR }
    val canApply: Boolean get() = source != null && patch != null && output != null && !hasErrors
}
