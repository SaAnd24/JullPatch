package com.jullpatch.app.service

import android.content.Context
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.history.HistoryCompletion
import com.jullpatch.app.domain.history.HistoryRepository
import com.jullpatch.app.domain.history.HistoryResult
import com.jullpatch.app.domain.history.NewHistoryEntry
import com.jullpatch.app.domain.model.PatchErrorKind
import com.jullpatch.app.domain.model.PatchFailure
import com.jullpatch.app.domain.model.PatchOutcome
import com.jullpatch.app.domain.model.PatchProgress
import com.jullpatch.app.domain.model.PatchRequest
import com.jullpatch.app.domain.model.PatchStage
import com.jullpatch.app.domain.usecase.ApplyPatchUseCase
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface JobState {
    data object Idle : JobState

    data class Running(
        val request: PatchRequest,
        val progress: PatchProgress,
        val cancelling: Boolean = false,
    ) : JobState

    data class Finished(
        val request: PatchRequest,
        val outcome: PatchOutcome,
    ) : JobState
}

/**
 * Application-scoped owner of the single running patch job. It outlives Activities, records every
 * run in the history, and [PatchForegroundService] keeps the process alive while a job runs.
 */
class PatchJobManager(
    private val appContext: Context,
    private val useCase: ApplyPatchUseCase,
    private val history: HistoryRepository,
    private val files: FileGateway,
    private val scope: CoroutineScope,
) {
    private val _state = MutableStateFlow<JobState>(JobState.Idle)
    val state: StateFlow<JobState> = _state.asStateFlow()

    private val cancelRequested = AtomicBoolean(false)
    private var job: Job? = null

    @Synchronized
    fun start(request: PatchRequest): Boolean {
        if (_state.value is JobState.Running) return false
        cancelRequested.set(false)
        _state.value = JobState.Running(
            request = request,
            progress = PatchProgress(
                stage = PatchStage.VALIDATING,
                fileName = request.source.name,
                outputName = request.output.name,
                patchTotalBytes = request.patch.sizeBytes,
            ),
        )
        PatchForegroundService.start(appContext)

        job = scope.launch(Dispatchers.IO) {
            val startedAt = System.currentTimeMillis()
            // Marked RUNNING first: if the process dies, the next start finds it and cleans up.
            val entryId: Long? = runCatching {
                history.start(
                    NewHistoryEntry(
                        startedAt = startedAt,
                        sourceName = request.source.name,
                        sourceUri = request.source.uri.toString(),
                        patchName = request.patch.name,
                        patchUri = request.patch.uri.toString(),
                        outputName = request.output.name,
                        outputUri = request.output.uri.toString(),
                    ),
                )
            }.getOrNull()
            runCatching { files.retainAccess(request.output.uri) }

            val outcome = try {
                useCase.execute(
                    request = request,
                    isCancelled = { cancelRequested.get() },
                    onProgress = { progress ->
                        _state.update { current ->
                            if (current is JobState.Running) {
                                current.copy(
                                    progress = if (current.cancelling) progress.copy(stage = PatchStage.CANCELLING) else progress,
                                )
                            } else {
                                current
                            }
                        }
                    },
                )
            } catch (e: Throwable) {
                files.delete(request.output.uri)
                PatchOutcome.Failure(PatchFailure(PatchErrorKind.UNEXPECTED, e.toString()))
            }

            if (entryId != null) {
                runCatching { history.finish(entryId, outcome.toCompletion(startedAt)) }
            }
            runCatching { files.releaseAccess(request.output.uri) }
            _state.value = JobState.Finished(request, outcome)
        }
        return true
    }

    /** Safe at any moment: the engine stops at its next checkpoint and the partial output is deleted. */
    fun cancel() {
        cancelRequested.set(true)
        _state.update { current ->
            if (current is JobState.Running) {
                current.copy(cancelling = true, progress = current.progress.copy(stage = PatchStage.CANCELLING))
            } else {
                current
            }
        }
    }

    /** Leaves the finished state (user pressed "Volver"). No-op while a job is running. */
    fun reset() {
        _state.update { current -> if (current is JobState.Finished) JobState.Idle else current }
    }

    private fun PatchOutcome.toCompletion(startedAt: Long): HistoryCompletion {
        val now = System.currentTimeMillis()
        val duration = now - startedAt
        return when (this) {
            is PatchOutcome.Success -> HistoryCompletion(
                result = HistoryResult.SUCCESS,
                finishedAt = now,
                outputSize = outputBytes,
                durationMs = duration,
            )
            is PatchOutcome.Failure -> HistoryCompletion(
                result = HistoryResult.FAILED,
                finishedAt = now,
                errorKind = failure.kind,
                errorDetail = failure.technicalDetail,
                durationMs = duration,
            )
            PatchOutcome.Cancelled -> HistoryCompletion(
                result = HistoryResult.CANCELLED,
                finishedAt = now,
                durationMs = duration,
            )
        }
    }
}
