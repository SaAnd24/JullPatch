package com.jullpatch.app.data.engine

/**
 * JNI binding to the native VCDIFF/XDelta decoder (app/src/main/cpp).
 * Keep [NativeStatus] values in sync with Status in vcdiff/status.h.
 */
object NativeXdelta {
    init {
        System.loadLibrary("jullpatch")
    }

    /** Callbacks invoked from the native thread (the same thread that called [nativeApply]). */
    interface Listener {
        /** @return false to cancel. */
        fun onProgress(patchBytesRead: Long, outputBytes: Long): Boolean

        /** Human-readable detail for a non-successful status. */
        fun onMessage(message: String)
    }

    /**
     * Blocking. Reads [sourceFd] with positional reads, [patchFd] sequentially and writes
     * [outputFd] sequentially. File descriptors remain owned by the caller.
     * Sizes may be -1 when unknown. Returns a [NativeStatus] code.
     */
    @JvmStatic
    external fun nativeApply(
        sourceFd: Int,
        patchFd: Int,
        outputFd: Int,
        sourceSize: Long,
        patchSize: Long,
        listener: Listener,
    ): Int

    /**
     * Walks the patch's window headers (positional reads, no decoding) and returns
     * [status, windows, totalTargetBytes, maxWindowBytes, minSourceBytes, flags, secondaryId].
     */
    @JvmStatic
    external fun nativeInspect(patchFd: Int, patchSize: Long): LongArray?
}

/** Bit flags returned by nativeInspect (keep in sync with vcdiff_inspector.h). */
object InspectFlags {
    const val ALL_CHECKSUMS = 1L
    const val USES_SOURCE = 2L
    const val USES_LZMA = 4L
    const val UNSUPPORTED_SECONDARY = 8L
    const val TARGET_WINDOWS = 16L
    const val CUSTOM_CODE_TABLE = 32L
    const val WINDOW_TOO_LARGE = 64L
}

object NativeStatus {
    const val OK = 0
    const val CANCELLED = 1
    const val NOT_VCDIFF = 2
    const val CORRUPT_PATCH = 3
    const val UNSUPPORTED = 4
    const val SOURCE_READ_ERROR = 5
    const val PATCH_READ_ERROR = 6
    const val OUTPUT_WRITE_ERROR = 7
    const val NO_SPACE = 8
    const val CHECKSUM_MISMATCH = 9
    const val OUT_OF_MEMORY = 10
    const val INTERNAL = 11
    const val SOURCE_NOT_SEEKABLE = 12
    const val SOURCE_TOO_SMALL = 13
}
