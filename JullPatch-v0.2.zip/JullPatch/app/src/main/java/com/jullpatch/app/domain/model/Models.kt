package com.jullpatch.app.domain.model

import android.net.Uri

/** A file chosen through the Storage Access Framework. Never a filesystem path. */
data class FileRef(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long?,
    val lastModified: Long? = null,
)

data class PatchRequest(
    val source: FileRef,
    val patch: FileRef,
    val output: FileRef,
)

enum class PatchErrorKind {
    SOURCE_NOT_FOUND,
    SOURCE_UNREADABLE,
    PATCH_NOT_FOUND,
    PATCH_UNREADABLE,
    OUTPUT_UNWRITABLE,
    OUTPUT_SAME_AS_INPUT,
    NOT_A_PATCH,
    PATCH_CORRUPT,
    UNSUPPORTED_PATCH,
    SOURCE_MISMATCH,
    SOURCE_TOO_SMALL,
    SOURCE_NOT_SEEKABLE,
    READ_ERROR,
    WRITE_ERROR,
    NO_SPACE,
    OUT_OF_MEMORY,
    OUTPUT_INCOMPLETE,
    UNEXPECTED,
}

data class PatchFailure(
    val kind: PatchErrorKind,
    /** Raw detail for diagnostics; not meant as the primary user message. */
    val technicalDetail: String? = null,
)

enum class PatchStage { VALIDATING, OPENING, PATCHING, CANCELLING }

data class PatchProgress(
    val stage: PatchStage,
    val fileName: String,
    val outputName: String = "",
    val patchBytesRead: Long = 0L,
    val patchTotalBytes: Long? = null,
    val outputBytes: Long = 0L,
    /** Exact size of the final output, known from the patch inspection. */
    val expectedOutputBytes: Long? = null,
    val bytesPerSecond: Long? = null,
    val etaSeconds: Long? = null,
) {
    /**
     * Real progress. Prefers bytes written versus the exact expected output size and falls back to
     * the fraction of the patch consumed. Null when neither total is known.
     */
    val fraction: Float?
        get() {
            val expected = expectedOutputBytes
            if (expected != null && expected > 0L) {
                return (outputBytes.toDouble() / expected.toDouble()).toFloat().coerceIn(0f, 1f)
            }
            val total = patchTotalBytes ?: return null
            if (total <= 0L) return null
            return (patchBytesRead.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
        }
}

sealed interface PatchOutcome {
    data class Success(
        val output: FileRef,
        val outputBytes: Long,
        val elapsedMillis: Long,
    ) : PatchOutcome

    data class Failure(val failure: PatchFailure) : PatchOutcome

    data object Cancelled : PatchOutcome
}
