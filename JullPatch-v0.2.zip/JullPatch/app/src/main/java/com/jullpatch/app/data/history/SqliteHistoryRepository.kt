package com.jullpatch.app.data.history

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.jullpatch.app.domain.history.HistoryCompletion
import com.jullpatch.app.domain.history.HistoryEntry
import com.jullpatch.app.domain.history.HistoryRepository
import com.jullpatch.app.domain.history.HistoryResult
import com.jullpatch.app.domain.history.NewHistoryEntry
import com.jullpatch.app.domain.model.PatchErrorKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext

/** History stored in a private SQLite database (no extra dependencies). */
class SqliteHistoryRepository(context: Context) : HistoryRepository {

    private val helper = Helper(context.applicationContext)
    private val version = MutableStateFlow(0)

    override val entries: Flow<List<HistoryEntry>> =
        version.map { loadAll() }.flowOn(Dispatchers.IO)

    override suspend fun start(entry: NewHistoryEntry): Long = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(COL_STARTED, entry.startedAt)
            put(COL_SOURCE_NAME, entry.sourceName)
            put(COL_SOURCE_URI, entry.sourceUri)
            put(COL_PATCH_NAME, entry.patchName)
            put(COL_PATCH_URI, entry.patchUri)
            put(COL_OUTPUT_NAME, entry.outputName)
            put(COL_OUTPUT_URI, entry.outputUri)
            put(COL_RESULT, HistoryResult.RUNNING.name)
        }
        val db = helper.writableDatabase
        val id = db.insertOrThrow(TABLE, null, values)
        db.execSQL(
            "DELETE FROM $TABLE WHERE $COL_ID NOT IN (SELECT $COL_ID FROM $TABLE ORDER BY $COL_ID DESC LIMIT $MAX_ENTRIES)",
        )
        version.update { it + 1 }
        id
    }

    override suspend fun finish(id: Long, completion: HistoryCompletion) {
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put(COL_FINISHED, completion.finishedAt)
                put(COL_RESULT, completion.result.name)
                put(COL_OUTPUT_SIZE, completion.outputSize)
                put(COL_ERROR_KIND, completion.errorKind?.name)
                put(COL_ERROR_DETAIL, completion.errorDetail)
                put(COL_DURATION, completion.durationMs)
            }
            helper.writableDatabase.update(TABLE, values, "$COL_ID = ?", arrayOf(id.toString()))
            version.update { it + 1 }
        }
    }

    override suspend fun running(): List<HistoryEntry> = withContext(Dispatchers.IO) {
        query("$COL_RESULT = ?", arrayOf(HistoryResult.RUNNING.name), null)
    }

    override suspend fun delete(id: Long) {
        withContext(Dispatchers.IO) {
            helper.writableDatabase.delete(TABLE, "$COL_ID = ?", arrayOf(id.toString()))
            version.update { it + 1 }
        }
    }

    override suspend fun clear() {
        withContext(Dispatchers.IO) {
            // Keep entries that are still running so their cleanup information is not lost.
            helper.writableDatabase.delete(TABLE, "$COL_RESULT <> ?", arrayOf(HistoryResult.RUNNING.name))
            version.update { it + 1 }
        }
    }

    private fun loadAll(): List<HistoryEntry> = query(null, null, "$MAX_ENTRIES")

    private fun query(selection: String?, args: Array<String>?, limit: String?): List<HistoryEntry> {
        val result = ArrayList<HistoryEntry>()
        helper.readableDatabase.query(TABLE, null, selection, args, null, null, "$COL_ID DESC", limit).use { c ->
            while (c.moveToNext()) result.add(c.toEntry())
        }
        return result
    }

    private fun Cursor.toEntry(): HistoryEntry {
        fun str(col: String) = getString(getColumnIndexOrThrow(col))
        fun longOrNull(col: String): Long? {
            val i = getColumnIndexOrThrow(col)
            return if (isNull(i)) null else getLong(i)
        }
        return HistoryEntry(
            id = getLong(getColumnIndexOrThrow(COL_ID)),
            startedAt = getLong(getColumnIndexOrThrow(COL_STARTED)),
            finishedAt = longOrNull(COL_FINISHED),
            sourceName = str(COL_SOURCE_NAME),
            sourceUri = str(COL_SOURCE_URI),
            patchName = str(COL_PATCH_NAME),
            patchUri = str(COL_PATCH_URI),
            outputName = str(COL_OUTPUT_NAME),
            outputUri = str(COL_OUTPUT_URI),
            outputSize = longOrNull(COL_OUTPUT_SIZE),
            result = runCatching { HistoryResult.valueOf(str(COL_RESULT)) }.getOrDefault(HistoryResult.FAILED),
            errorKind = str(COL_ERROR_KIND)?.let { name ->
                runCatching { PatchErrorKind.valueOf(name) }.getOrNull()
            },
            errorDetail = str(COL_ERROR_DETAIL),
            durationMs = longOrNull(COL_DURATION),
        )
    }

    private class Helper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE $TABLE (
                    $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COL_STARTED INTEGER NOT NULL,
                    $COL_FINISHED INTEGER,
                    $COL_SOURCE_NAME TEXT NOT NULL,
                    $COL_SOURCE_URI TEXT NOT NULL,
                    $COL_PATCH_NAME TEXT NOT NULL,
                    $COL_PATCH_URI TEXT NOT NULL,
                    $COL_OUTPUT_NAME TEXT NOT NULL,
                    $COL_OUTPUT_URI TEXT NOT NULL,
                    $COL_OUTPUT_SIZE INTEGER,
                    $COL_RESULT TEXT NOT NULL,
                    $COL_ERROR_KIND TEXT,
                    $COL_ERROR_DETAIL TEXT,
                    $COL_DURATION INTEGER
                )
                """.trimIndent(),
            )
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            // Version 1 is the first schema. Future versions add columns here with ALTER TABLE
            // so existing history is preserved.
        }
    }

    private companion object {
        const val DB_NAME = "jullpatch.db"
        const val DB_VERSION = 1
        const val MAX_ENTRIES = 200
        const val TABLE = "history"
        const val COL_ID = "id"
        const val COL_STARTED = "started_at"
        const val COL_FINISHED = "finished_at"
        const val COL_SOURCE_NAME = "source_name"
        const val COL_SOURCE_URI = "source_uri"
        const val COL_PATCH_NAME = "patch_name"
        const val COL_PATCH_URI = "patch_uri"
        const val COL_OUTPUT_NAME = "output_name"
        const val COL_OUTPUT_URI = "output_uri"
        const val COL_OUTPUT_SIZE = "output_size"
        const val COL_RESULT = "result"
        const val COL_ERROR_KIND = "error_kind"
        const val COL_ERROR_DETAIL = "error_detail"
        const val COL_DURATION = "duration_ms"
    }
}
