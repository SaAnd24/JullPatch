package com.jullpatch.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.jullpatch.app.R
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.IssueSeverity
import com.jullpatch.app.domain.model.ValidationReport

/** A numbered step: the header selects a file, [content] holds extra info such as hashes. */
@Composable
internal fun StepCard(
    number: Int,
    title: String,
    hint: String,
    file: FileRef?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    showSize: Boolean = true,
    content: @Composable ColumnScope.() -> Unit = {},
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onClick),
                verticalAlignment = Alignment.Top,
            ) {
                StepBadge(number)
                Spacer(Modifier.width(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    if (file == null) {
                        Text(hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text(file.name, style = MaterialTheme.typography.titleMedium)
                        val details = buildList {
                            val size = file.sizeBytes
                            if (showSize && size != null) add(formatBytes(size))
                            file.lastModified?.let { add(stringResource(R.string.file_modified, formatDateTime(it))) }
                        }
                        if (details.isNotEmpty()) {
                            Text(
                                details.joinToString(" · "),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            content()
        }
    }
}

@Composable
private fun StepBadge(number: Int) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .background(MaterialTheme.colorScheme.primary, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(number.toString(), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge)
    }
}

/** Hash controls for one file: compute on demand (hashing multi-GB files takes time), show, cancel. */
@Composable
internal fun HashSection(
    state: HashUi?,
    onCompute: () -> Unit,
    onCancel: () -> Unit,
    computeLabel: String = stringResource(R.string.hashes_button),
) {
    Column(modifier = Modifier.padding(top = 4.dp)) {
        when (state) {
            null, HashUi.Idle -> TextButton(onClick = onCompute) { Text(computeLabel) }
            is HashUi.Running -> {
                val total = state.total
                val fraction = if (total != null && total > 0L) {
                    (state.processed.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
                } else {
                    null
                }
                if (fraction != null) {
                    LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        stringResource(
                            R.string.hashes_computing,
                            if (fraction != null) formatPercent(fraction) else formatBytes(state.processed),
                        ),
                        style = MaterialTheme.typography.bodySmall,
                    )
                    TextButton(onClick = onCancel) { Text(stringResource(R.string.hashes_cancel)) }
                }
            }
            is HashUi.Done -> SelectionContainer {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    for ((algorithm, value) in state.values) {
                        Text(
                            "${algorithm.label}: $value",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                        )
                    }
                }
            }
            is HashUi.Failed -> {
                Text(stringResource(state.messageRes), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = onCompute) { Text(computeLabel) }
            }
        }
    }
}

/** Step 4: the result of the pre-flight checks, including required vs. available space. */
@Composable
internal fun ValidationCard(validation: ValidationUi, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            StepBadge(4)
            Spacer(Modifier.width(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    stringResource(R.string.step_validation),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
                when (validation) {
                    ValidationUi.Idle -> Text(
                        stringResource(R.string.validation_idle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    ValidationUi.Running -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(stringResource(R.string.validation_running), style = MaterialTheme.typography.bodyMedium)
                    }
                    is ValidationUi.Ready -> ReportContent(validation.report)
                }
            }
        }
    }
}

@Composable
private fun ReportContent(report: ValidationReport) {
    val info = report.patchInfo
    val sourceSize = report.sourceSizeBytes
    val sourceBlocked = report.issues.any {
        it.severity == IssueSeverity.ERROR && it.code.name.startsWith("SOURCE_")
    }
    val patchBlocked = report.issues.any {
        it.severity == IssueSeverity.ERROR && it.code.name.startsWith("PATCH_")
    }

    if (report.source != null && !sourceBlocked) {
        CheckLine(true, stringResource(R.string.check_source_ok, sourceSize?.let(::formatBytes) ?: report.source.name))
    }
    if (info != null && !patchBlocked) {
        CheckLine(true, stringResource(R.string.check_patch_ok, info.windowCount.toInt(), formatBytes(info.totalOutputBytes)))
        if (info.hasChecksums) CheckLine(true, stringResource(R.string.check_checksums_ok))
    }
    report.space?.let { space ->
        val required = space.requiredBytes?.let(::formatBytes) ?: stringResource(R.string.space_unknown)
        val available = space.availableBytes?.let(::formatBytes) ?: stringResource(R.string.space_unknown)
        Text(stringResource(R.string.space_required, required), style = MaterialTheme.typography.bodyMedium)
        Text(stringResource(R.string.space_available, available), style = MaterialTheme.typography.bodyMedium)
    }
    for (issue in report.issues) {
        val isError = issue.severity == IssueSeverity.ERROR
        Text(
            (if (isError) "✗ " else "⚠ ") + issue.messageText(),
            style = MaterialTheme.typography.bodyMedium,
            color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary,
        )
    }
    val summary = when {
        report.hasErrors -> stringResource(R.string.validation_blocked)
        report.canApply -> stringResource(R.string.validation_ok)
        else -> stringResource(R.string.validation_incomplete)
    }
    Text(
        summary,
        style = MaterialTheme.typography.titleSmall,
        color = if (report.hasErrors) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
    )
}

@Composable
private fun CheckLine(ok: Boolean, text: String) {
    Text(
        (if (ok) "✓ " else "✗ ") + text,
        style = MaterialTheme.typography.bodyMedium,
    )
}

@Composable
internal fun ResultRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
