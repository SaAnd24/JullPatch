package com.jullpatch.app.data.engine

import com.jullpatch.app.domain.engine.PatchInspector
import com.jullpatch.app.domain.files.OpenedFile
import com.jullpatch.app.domain.model.InspectionResult
import com.jullpatch.app.domain.model.PatchErrorKind
import com.jullpatch.app.domain.model.PatchInfo
import com.jullpatch.app.domain.model.UnsupportedFeature

/** Inspects VCDIFF/XDelta patches through the native engine. */
class XdeltaPatchInspector : PatchInspector {

    override fun inspect(patch: OpenedFile): InspectionResult {
        val raw = try {
            NativeXdelta.nativeInspect(patch.fd, patch.sizeBytes ?: -1L)
        } catch (e: LinkageError) {
            return InspectionResult.Invalid(PatchErrorKind.UNEXPECTED, "Motor nativo no disponible: ${e.message}")
        }
        if (raw == null || raw.size < 7) {
            return InspectionResult.Invalid(PatchErrorKind.UNEXPECTED, "Respuesta nativa inválida")
        }

        when (raw[0].toInt()) {
            NativeStatus.OK -> Unit
            NativeStatus.NOT_VCDIFF -> return InspectionResult.Invalid(PatchErrorKind.NOT_A_PATCH)
            NativeStatus.CORRUPT_PATCH -> return InspectionResult.Invalid(PatchErrorKind.PATCH_CORRUPT)
            NativeStatus.UNSUPPORTED -> return InspectionResult.Invalid(PatchErrorKind.UNSUPPORTED_PATCH)
            NativeStatus.SOURCE_NOT_SEEKABLE -> return InspectionResult.Unavailable
            NativeStatus.PATCH_READ_ERROR -> return InspectionResult.Invalid(PatchErrorKind.READ_ERROR)
            else -> return InspectionResult.Invalid(PatchErrorKind.UNEXPECTED, "Estado nativo ${raw[0]}")
        }

        val flags = raw[5]
        val unsupported = buildSet {
            if (flags and InspectFlags.UNSUPPORTED_SECONDARY != 0L) add(UnsupportedFeature.SECONDARY_COMPRESSION)
            if (flags and InspectFlags.TARGET_WINDOWS != 0L) add(UnsupportedFeature.TARGET_WINDOWS)
            if (flags and InspectFlags.CUSTOM_CODE_TABLE != 0L) add(UnsupportedFeature.CUSTOM_CODE_TABLE)
            if (flags and InspectFlags.WINDOW_TOO_LARGE != 0L) add(UnsupportedFeature.WINDOW_TOO_LARGE)
        }
        return InspectionResult.Info(
            PatchInfo(
                windowCount = raw[1],
                totalOutputBytes = raw[2],
                maxWindowBytes = raw[3],
                minSourceBytes = raw[4],
                hasChecksums = flags and InspectFlags.ALL_CHECKSUMS != 0L,
                usesSourceFile = flags and InspectFlags.USES_SOURCE != 0L,
                usesLzma = flags and InspectFlags.USES_LZMA != 0L,
                unsupported = unsupported,
            ),
        )
    }
}
