package com.jullpatch.app

import android.app.Application
import com.jullpatch.app.data.engine.XdeltaPatchEngine
import com.jullpatch.app.data.engine.XdeltaPatchInspector
import com.jullpatch.app.data.files.ContentResolverFileGateway
import com.jullpatch.app.data.history.SqliteHistoryRepository
import com.jullpatch.app.domain.engine.PatchEngine
import com.jullpatch.app.domain.engine.PatchInspector
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.hashing.HashCache
import com.jullpatch.app.domain.hashing.InMemoryHashCache
import com.jullpatch.app.domain.hashing.StreamHasher
import com.jullpatch.app.domain.history.HistoryRepository
import com.jullpatch.app.domain.usecase.ApplyPatchUseCase
import com.jullpatch.app.domain.usecase.ComputeHashesUseCase
import com.jullpatch.app.domain.usecase.RecoverInterruptedJobsUseCase
import com.jullpatch.app.domain.usecase.ValidatePatchUseCase
import com.jullpatch.app.service.PatchJobManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Manual dependency container. Swap [engine] / [inspector] to plug in other patch formats later,
 * and [history] / [hashCache] to change how data is stored.
 */
class AppContainer(application: Application) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val fileGateway: FileGateway = ContentResolverFileGateway(application.contentResolver)
    val engine: PatchEngine = XdeltaPatchEngine()
    val inspector: PatchInspector = XdeltaPatchInspector()
    val history: HistoryRepository = SqliteHistoryRepository(application)
    val hashCache: HashCache = InMemoryHashCache()

    val validatePatch = ValidatePatchUseCase(fileGateway, inspector)
    val applyPatch = ApplyPatchUseCase(fileGateway, engine, validatePatch)
    val computeHashes = ComputeHashesUseCase(fileGateway, StreamHasher(), hashCache)
    val recoverInterruptedJobs = RecoverInterruptedJobsUseCase(history, fileGateway)

    val jobManager = PatchJobManager(
        appContext = application,
        useCase = applyPatch,
        history = history,
        files = fileGateway,
        scope = appScope,
    )
}
