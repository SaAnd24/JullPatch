package com.jullpatch.app.ui

import android.net.Uri
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.jullpatch.app.AppContainer
import com.jullpatch.app.domain.files.FileAccessException
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.files.FileRole
import com.jullpatch.app.domain.hashing.HashAlgorithm
import com.jullpatch.app.domain.history.HistoryEntry
import com.jullpatch.app.domain.history.HistoryRepository
import com.jullpatch.app.domain.model.FileRef
import com.jullpatch.app.domain.model.PatchErrorKind
import com.jullpatch.app.domain.model.PatchOutcome
import com.jullpatch.app.domain.model.PatchRequest
import com.jullpatch.app.domain.model.ValidationReport
import com.jullpatch.app.domain.usecase.ComputeHashesUseCase
import com.jullpatch.app.domain.usecase.HashOutcome
import com.jullpatch.app.domain.usecase.ValidatePatchUseCase
import com.jullpatch.app.service.JobState
import com.jullpatch.app.service.PatchJobManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen { HOME, FORM, HISTORY }

enum class HashTarget { SOURCE, PATCH, OUTPUT }

sealed interface HashUi {
    data object Idle : HashUi
    data class Running(val processed: Long, val total: Long?) : HashUi
    data class Done(val values: Map<HashAlgorithm, String>) : HashUi
    data class Failed(@StringRes val messageRes: Int) : HashUi
}

sealed interface ValidationUi {
    data object Idle : ValidationUi
    data object Running : ValidationUi
    data class Ready(val report: ValidationReport) : ValidationUi
}

data class MainUiState(
    val screen: Screen = Screen.HOME,
    val source: FileRef? = null,
    val patch: FileRef? = null,
    val output: FileRef? = null,
    @StringRes val messageRes: Int? = null,
    val validation: ValidationUi = ValidationUi.Idle,
    val hashes: Map<HashTarget, HashUi> = emptyMap(),
    val job: JobState = JobState.Idle,
    val history: List<HistoryEntry> = emptyList(),
) {
    /** Apply is possible only when the validation of the *current* selection passed. */
    val canApply: Boolean
        get() = (validation as? ValidationUi.Ready)?.report?.canApply == true
    val suggestedOutputName: String
        get() = source?.name?.let(::suggestOutputName) ?: "parcheado.bin"
}

class MainViewModel(
    private val files: FileGateway,
    private val jobs: PatchJobManager,
    private val validate: ValidatePatchUseCase,
    private val hashUseCase: ComputeHashesUseCase,
    private val historyRepository: HistoryRepository,
) : ViewModel() {

    private data class Local(
        val screen: Screen = Screen.HOME,
        val source: FileRef? = null,
        val patch: FileRef? = null,
        val output: FileRef? = null,
        @StringRes val messageRes: Int? = null,
        val validation: ValidationUi = ValidationUi.Idle,
        val hashes: Map<HashTarget, HashUi> = emptyMap(),
    )

    private val local = MutableStateFlow(Local())
    private var validationJob: Job? = null
    private val hashJobs = mutableMapOf<HashTarget, Job>()

    val uiState: StateFlow<MainUiState> =
        combine(local, jobs.state, historyRepository.entries) { l, j, h -> toUi(l, j, h) }
            .stateIn(viewModelScope, SharingStarted.Eagerly, toUi(local.value, jobs.state.value, emptyList()))

    private fun toUi(l: Local, j: JobState, h: List<HistoryEntry>) = MainUiState(
        screen = l.screen,
        source = l.source,
        patch = l.patch,
        output = l.output,
        messageRes = l.messageRes,
        validation = l.validation,
        hashes = l.hashes,
        job = j,
        history = h,
    )

    // ---- Navigation ---------------------------------------------------------------------------

    fun openForm() = local.update { it.copy(screen = Screen.FORM, messageRes = null) }

    fun openHistory() = local.update { it.copy(screen = Screen.HISTORY, messageRes = null) }

    /** Leaves the form. The destination document was created empty by the picker, so remove it. */
    fun backToHome() {
        validationJob?.cancel()
        val unusedOutput = local.value.output
        local.update { it.copy(screen = Screen.HOME, output = null, messageRes = null, validation = ValidationUi.Idle) }
        if (unusedOutput != null) discard(unusedOutput)
        revalidate()
    }

    fun closeHistory() = local.update { it.copy(screen = Screen.HOME) }

    fun clearHistory() {
        viewModelScope.launch { runCatching { historyRepository.clear() } }
    }

    // ---- Selection ----------------------------------------------------------------------------

    fun onSourcePicked(uri: Uri) = describe(uri, FileRole.SOURCE, HashTarget.SOURCE) { l, f -> l.copy(source = f) }

    fun onPatchPicked(uri: Uri) = describe(uri, FileRole.PATCH, HashTarget.PATCH) { l, f -> l.copy(patch = f) }

    fun onOutputPicked(uri: Uri) {
        val previous = local.value.output
        describe(uri, FileRole.OUTPUT, null) { l, f -> l.copy(output = f) }
        if (previous != null && previous.uri != uri) discard(previous)
    }

    /**
     * Reads the file's metadata off the main thread, stores it, drops any hashes computed for the
     * previous file in that slot, and re-validates.
     */
    private fun describe(
        uri: Uri,
        role: FileRole,
        hashTarget: HashTarget?,
        transform: (Local, FileRef) -> Local,
    ) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { files.describe(uri, role) } }
            result.onSuccess { ref ->
                if (hashTarget != null) hashJobs.remove(hashTarget)?.cancel()
                local.update { current ->
                    val updated = transform(current, ref).copy(messageRes = null)
                    if (hashTarget != null) updated.copy(hashes = updated.hashes - hashTarget) else updated
                }
                revalidate()
            }.onFailure { e ->
                val kind = (e as? FileAccessException)?.kind ?: PatchErrorKind.UNEXPECTED
                local.update { it.copy(messageRes = kind.messageRes()) }
            }
        }
    }

    private fun discard(file: FileRef) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { files.delete(file.uri) } }
    }

    // ---- Validation ---------------------------------------------------------------------------

    private fun revalidate() {
        validationJob?.cancel()
        val l = local.value
        if (l.source == null && l.patch == null && l.output == null) {
            local.update { it.copy(validation = ValidationUi.Idle) }
            return
        }
        local.update { it.copy(validation = ValidationUi.Running) }
        validationJob = viewModelScope.launch {
            val self = coroutineContext[Job]
            val report = withContext(Dispatchers.IO) {
                validate.execute(l.source, l.patch, l.output) { self?.isActive != true }
            }
            if (self?.isActive == true) {
                local.update { it.copy(validation = ValidationUi.Ready(report)) }
            }
        }
    }

    // ---- Hashes -------------------------------------------------------------------------------

    fun computeHashes(target: HashTarget) {
        val l = local.value
        val finished = jobs.state.value as? JobState.Finished
        val file: FileRef?
        val role: FileRole
        when (target) {
            HashTarget.SOURCE -> {
                file = l.source
                role = FileRole.SOURCE
            }
            HashTarget.PATCH -> {
                file = l.patch
                role = FileRole.PATCH
            }
            HashTarget.OUTPUT -> {
                file = (finished?.outcome as? PatchOutcome.Success)?.output
                role = FileRole.SOURCE // the finished output is read like any other file
            }
        }
        if (file == null) return

        hashJobs[target]?.cancel()
        setHash(target, HashUi.Running(0L, file.sizeBytes))
        hashJobs[target] = viewModelScope.launch {
            val self = coroutineContext[Job]
            val outcome = withContext(Dispatchers.IO) {
                hashUseCase.execute(
                    file = file,
                    role = role,
                    isCancelled = { self?.isActive != true },
                    onProgress = { processed, total -> setHash(target, HashUi.Running(processed, total)) },
                )
            }
            if (self?.isActive != true) return@launch
            when (outcome) {
                is HashOutcome.Done -> setHash(target, HashUi.Done(outcome.values))
                HashOutcome.Cancelled -> setHash(target, null)
                is HashOutcome.Failed -> setHash(target, HashUi.Failed(outcome.kind.messageRes()))
            }
        }
    }

    fun cancelHashes(target: HashTarget) = cancelHash(target)

    private fun cancelHash(target: HashTarget) {
        hashJobs.remove(target)?.cancel()
        setHash(target, null)
    }

    private fun setHash(target: HashTarget, state: HashUi?) {
        local.update { l ->
            l.copy(hashes = if (state == null) l.hashes - target else l.hashes + (target to state))
        }
    }

    // ---- Patching -----------------------------------------------------------------------------

    fun startPatch() {
        val l = local.value
        val source = l.source
        val patch = l.patch
        val output = l.output
        if (source == null || patch == null || output == null) return
        validationJob?.cancel()
        local.update { it.copy(messageRes = null) }
        jobs.start(PatchRequest(source, patch, output))
    }

    fun cancelPatch() = jobs.cancel()

    /** "Volver" on a result screen. */
    fun dismissResult() {
        val finished = jobs.state.value as? JobState.Finished ?: return
        cancelHash(HashTarget.OUTPUT)
        jobs.reset()
        if (finished.outcome is PatchOutcome.Success) {
            local.value = Local()
        } else {
            // The output document was deleted; keep the inputs so the user can retry.
            local.update { it.copy(screen = Screen.FORM, output = null, messageRes = null) }
            revalidate()
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                MainViewModel(
                    files = container.fileGateway,
                    jobs = container.jobManager,
                    validate = container.validatePatch,
                    hashUseCase = container.computeHashes,
                    historyRepository = container.history,
                )
            }
        }
    }
}
