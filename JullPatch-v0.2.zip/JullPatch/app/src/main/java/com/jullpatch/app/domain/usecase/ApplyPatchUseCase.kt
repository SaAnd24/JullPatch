package com.jullpatch.app.domain.usecase

import com.jullpatch.app.domain.engine.EngineResult
import com.jullpatch.app.domain.engine.PatchEngine
import com.jullpatch.app.domain.files.FileAccessException
import com.jullpatch.app.domain.files.FileGateway
import com.jullpatch.app.domain.files.FileRole
import com.jullpatch.app.domain.files.OpenedFile
import com.jullpatch.app.domain.model.PatchErrorKind
import com.jullpatch.app.domain.model.PatchFailure
import com.jullpatch.app.domain.model.PatchOutcome
import com.jullpatch.app.domain.model.PatchProgress
import com.jullpatch.app.domain.model.PatchRequest
import com.jullpatch.app.domain.model.PatchStage

/**
 * Orchestrates one patch run: validates again (free space may have changed), opens the files,
 * runs the engine and guarantees that no incomplete output is left behind on failure,
 * cancellation or a size mismatch.
 *
 * Blocking: call from a background dispatcher.
 */
class ApplyPatchUseCase(
    private val files: FileGateway,
    private val engine: PatchEngine,
    private val validate: ValidatePatchUseCase,
) {

    fun execute(
        request: PatchRequest,
        isCancelled: () -> Boolean,
        onProgress: (PatchProgress) -> Unit,
    ): PatchOutcome {
        val startedAt = System.currentTimeMillis()
        val inputName = request.source.name
        val outputName = request.output.name

        fun progress(
            stage: PatchStage,
            patchBytes: Long = 0L,
            patchTotal: Long? = request.patch.sizeBytes,
            outputBytes: Long = 0L,
            expected: Long? = null,
            speed: Long? = null,
            eta: Long? = null,
        ) = PatchProgress(stage, inputName, outputName, patchBytes, patchTotal, outputBytes, expected, speed, eta)

        onProgress(progress(PatchStage.VALIDATING))
        val report = validate.execute(request.source, request.patch, request.output, isCancelled)
        if (isCancelled()) {
            files.delete(request.output.uri)
            return PatchOutcome.Cancelled
        }
        report.firstError?.let { issue ->
            files.delete(request.output.uri)
            val kind = issue.code.errorKind ?: PatchErrorKind.UNEXPECTED
            return PatchOutcome.Failure(PatchFailure(kind, issue.args.joinToString(", ").ifEmpty { null }))
        }
        val expectedOutput = report.patchInfo?.totalOutputBytes

        onProgress(progress(PatchStage.OPENING, expected = expectedOutput))

        var source: OpenedFile? = null
        var patch: OpenedFile? = null
        var output: OpenedFile? = null
        val patchingStartNs = System.nanoTime()
        val result: EngineResult = try {
            val src = files.openForRead(request.source.uri, FileRole.SOURCE)
            source = src
            val pch = files.openForRead(request.patch.uri, FileRole.PATCH)
            patch = pch
            val out = files.openForWrite(request.output.uri)
            output = out

            val patchTotal = pch.sizeBytes ?: request.patch.sizeBytes
            onProgress(progress(PatchStage.PATCHING, patchTotal = patchTotal, expected = expectedOutput))

            engine.apply(src, pch, out) { patchBytes, outputBytes ->
                if (isCancelled()) {
                    false
                } else {
                    val elapsedSec = (System.nanoTime() - patchingStartNs) / 1_000_000_000.0
                    var speed: Long? = null
                    var eta: Long? = null
                    if (elapsedSec >= 1.0 && outputBytes > 0L) {
                        val bytesPerSecond = outputBytes / elapsedSec
                        speed = bytesPerSecond.toLong()
                        if (expectedOutput != null && bytesPerSecond > 0.0 && expectedOutput >= outputBytes) {
                            eta = ((expectedOutput - outputBytes) / bytesPerSecond).toLong()
                        }
                    }
                    onProgress(
                        progress(PatchStage.PATCHING, patchBytes, patchTotal, outputBytes, expectedOutput, speed, eta),
                    )
                    true
                }
            }
        } catch (e: FileAccessException) {
            EngineResult.Failure(PatchFailure(e.kind, e.message))
        } catch (e: Throwable) {
            EngineResult.Failure(PatchFailure(PatchErrorKind.UNEXPECTED, e.toString()))
        } finally {
            output?.close()
            patch?.close()
            source?.close()
        }

        return when (result) {
            is EngineResult.Success -> {
                // The engine counts the bytes it actually wrote; anything else is an incomplete file.
                if (expectedOutput != null && result.outputBytes != expectedOutput) {
                    files.delete(request.output.uri)
                    PatchOutcome.Failure(
                        PatchFailure(
                            PatchErrorKind.OUTPUT_INCOMPLETE,
                            "escritos ${result.outputBytes} de $expectedOutput bytes",
                        ),
                    )
                } else {
                    PatchOutcome.Success(
                        output = request.output.copy(sizeBytes = result.outputBytes),
                        outputBytes = result.outputBytes,
                        elapsedMillis = System.currentTimeMillis() - startedAt,
                    )
                }
            }
            is EngineResult.Cancelled -> {
                files.delete(request.output.uri)
                PatchOutcome.Cancelled
            }
            is EngineResult.Failure -> {
                files.delete(request.output.uri)
                PatchOutcome.Failure(result.failure)
            }
        }
    }
}
