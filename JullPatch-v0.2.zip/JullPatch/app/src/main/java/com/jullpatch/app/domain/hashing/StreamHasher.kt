package com.jullpatch.app.domain.hashing

import java.io.InputStream

sealed interface HashResult {
    data class Done(val values: Map<HashAlgorithm, String>) : HashResult
    data object Cancelled : HashResult
}

/**
 * Computes several hashes in a single pass over a stream, using one reusable buffer.
 * Memory use is [bufferSize] regardless of file size. Pure JVM: no Android dependencies.
 */
class StreamHasher(private val bufferSize: Int = 1 shl 20) {

    fun hash(
        input: InputStream,
        algorithms: Set<HashAlgorithm>,
        isCancelled: () -> Boolean = { false },
        onProgress: (bytesProcessed: Long) -> Unit = {},
    ): HashResult {
        require(algorithms.isNotEmpty()) { "At least one algorithm is required" }
        val digests = algorithms.sortedBy { it.ordinal }.map { it to it.newDigest() }
        val buffer = ByteArray(bufferSize)
        var total = 0L
        while (true) {
            if (isCancelled()) return HashResult.Cancelled
            val n = input.read(buffer)
            if (n < 0) break
            if (n == 0) continue
            for ((_, digest) in digests) digest.update(buffer, 0, n)
            total += n
            onProgress(total)
        }
        val values = LinkedHashMap<HashAlgorithm, String>()
        for ((algorithm, digest) in digests) values[algorithm] = digest.digestHex()
        return HashResult.Done(values)
    }
}
