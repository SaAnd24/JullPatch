package com.jullpatch.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.jullpatch.app.R
import com.jullpatch.app.domain.history.HistoryEntry
import com.jullpatch.app.domain.history.HistoryResult

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HistoryScreen(state: MainUiState, actions: MainActions) {
    BackHandler(onBack = actions.onCloseHistory)
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(stringResource(R.string.history_title)) },
            windowInsets = WindowInsets(0, 0, 0, 0),
            navigationIcon = {
                IconButton(onClick = actions.onCloseHistory) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back_description))
                }
            },
            actions = {
                if (state.history.isNotEmpty()) {
                    TextButton(onClick = actions.onClearHistory) { Text(stringResource(R.string.action_clear_history)) }
                }
            },
        )
        if (state.history.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    stringResource(R.string.history_empty),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(state.history, key = { it.id }) { entry -> HistoryItem(entry) }
            }
        }
    }
}

@Composable
private fun HistoryItem(entry: HistoryEntry) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                stringResource(resultLabel(entry.result)),
                style = MaterialTheme.typography.titleSmall,
                color = resultColor(entry.result),
            )
            Text(
                formatDateTime(entry.startedAt),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(stringResource(R.string.history_source, entry.sourceName), style = MaterialTheme.typography.bodyMedium)
            Text(stringResource(R.string.history_patch, entry.patchName), style = MaterialTheme.typography.bodyMedium)
            val sizeText = entry.outputSize?.let { " · " + formatBytes(it) }.orEmpty()
            Text(stringResource(R.string.history_output, entry.outputName) + sizeText, style = MaterialTheme.typography.bodyMedium)
            entry.durationMs?.let {
                Text(
                    stringResource(R.string.result_time) + ": " + formatDuration(it),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            entry.errorKind?.let { kind ->
                Text(stringResource(kind.messageRes()), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            if (entry.result == HistoryResult.INTERRUPTED) {
                Text(
                    stringResource(R.string.history_interrupted_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun resultLabel(result: HistoryResult): Int = when (result) {
    HistoryResult.RUNNING -> R.string.history_result_running
    HistoryResult.SUCCESS -> R.string.history_result_success
    HistoryResult.FAILED -> R.string.history_result_failed
    HistoryResult.CANCELLED -> R.string.history_result_cancelled
    HistoryResult.INTERRUPTED -> R.string.history_result_interrupted
}

@Composable
private fun resultColor(result: HistoryResult): Color = when (result) {
    HistoryResult.SUCCESS -> MaterialTheme.colorScheme.primary
    HistoryResult.FAILED -> MaterialTheme.colorScheme.error
    HistoryResult.RUNNING, HistoryResult.CANCELLED, HistoryResult.INTERRUPTED -> MaterialTheme.colorScheme.secondary
}
