package com.jullpatch.app.domain.hashing

import java.io.ByteArrayInputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamHasherTest {

    private fun hashAll(data: ByteArray, bufferSize: Int = 1 shl 20): Map<HashAlgorithm, String> {
        val result = StreamHasher(bufferSize).hash(ByteArrayInputStream(data), HashAlgorithm.entries.toSet())
        return (result as HashResult.Done).values
    }

    @Test
    fun knownVectors_abc() {
        val h = hashAll("abc".toByteArray())
        assertEquals("352441c2", h[HashAlgorithm.CRC32])
        assertEquals("900150983cd24fb0d6963f7d28e17f72", h[HashAlgorithm.MD5])
        assertEquals("a9993e364706816aba3e25717850c26c9cd0d89d", h[HashAlgorithm.SHA1])
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", h[HashAlgorithm.SHA256])
    }

    @Test
    fun knownVectors_empty() {
        val h = hashAll(ByteArray(0))
        assertEquals("00000000", h[HashAlgorithm.CRC32])
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", h[HashAlgorithm.MD5])
        assertEquals("da39a3ee5e6b4b0d3255bfef95601890afd80709", h[HashAlgorithm.SHA1])
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", h[HashAlgorithm.SHA256])
    }

    @Test
    fun crc32_checkValue() {
        assertEquals("cbf43926", hashAll("123456789".toByteArray())[HashAlgorithm.CRC32])
    }

    @Test
    fun result_isIndependentOfBufferSize() {
        val data = ByteArray(100_003) { (it * 31 + 7).toByte() }
        assertEquals(hashAll(data, 1 shl 20), hashAll(data, 7))
    }

    @Test
    fun onlyRequestedAlgorithmsAreComputed() {
        val result = StreamHasher().hash(ByteArrayInputStream("abc".toByteArray()), setOf(HashAlgorithm.MD5))
        assertEquals(setOf(HashAlgorithm.MD5), (result as HashResult.Done).values.keys)
    }

    @Test
    fun cancellation_stopsTheRead() {
        val data = ByteArray(1_000_000)
        var calls = 0
        val result = StreamHasher(1024).hash(
            ByteArrayInputStream(data),
            setOf(HashAlgorithm.SHA256),
            isCancelled = { ++calls > 3 },
        )
        assertTrue(result is HashResult.Cancelled)
    }

    @Test
    fun progress_reportsTotalBytes() {
        var last = 0L
        StreamHasher(10).hash(ByteArrayInputStream(ByteArray(95)), setOf(HashAlgorithm.CRC32), onProgress = { last = it })
        assertEquals(95L, last)
    }

    @Test
    fun cache_mergesAlgorithmsPerFile() {
        val cache = InMemoryHashCache()
        val key = FileFingerprint("content://x/1", 10L, 5L)
        cache.put(key, mapOf(HashAlgorithm.MD5 to "aa"))
        cache.put(key, mapOf(HashAlgorithm.CRC32 to "bb"))
        assertEquals(mapOf(HashAlgorithm.MD5 to "aa", HashAlgorithm.CRC32 to "bb"), cache.get(key))
        // A changed file (different size / mtime) is a different key.
        assertTrue(cache.get(FileFingerprint("content://x/1", 11L, 5L)).isEmpty())
        assertTrue(cache.get(FileFingerprint("content://x/1", 10L, 6L)).isEmpty())
    }
}
